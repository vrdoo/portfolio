export const environment = {
  production: true,
  baseUrl: 'https://controlled-health-api.fly.dev/api',
};
