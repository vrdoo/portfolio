import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import {
  CreateAccountRequest,
  Credentials,
  MessageResponse,
  PasswordCombination,
  UpdateAccountResponse,
  User,
  UserDataResponse,
} from '../models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private url = `${environment.baseUrl}`;

  constructor(private http: HttpClient) { }

  // User account

  createAccount(account: CreateAccountRequest): Observable<string> {
    const { email, password, passwordConfirmation } = account;

    const data = {
      email,
      password,
      password_confirmation: passwordConfirmation,
    };

    return this.http
      .post<any>(`${this.url}/user`, data)
      .pipe(map(() => 'Your account has been successfully created.'));
  }

  updateAccount(user: User,id:number): Observable<UpdateAccountResponse> {
    return this.http
      .patch<UserDataResponse>(`${this.url}/user/${id}`, {
        date_of_birth: user.date_of_birth,
        email: user.email,
        gender: user.gender,
        name: user.name,
      })
      .pipe(
        map((resp) => ({
          ...resp,
          message: 'Your account has been successfully updated.',
        }))
      );
  }

  deleteAccount(id:number): Observable<string> {
    return this.http
      .delete(`${this.url}/user/${id}`)
      .pipe(map(() => 'Your account has been successfully deleted.'));

  }

  // Password

  forgotPassword(email: string): Observable<string> {
    const data = {
      email,
    };

    return this.http
      .post<MessageResponse>(`${this.url}/user/password`, data)
      .pipe(map((resp) => resp.message));
  }

  updatePassword(passwordCombination: PasswordCombination, id: number): Observable<string> {
    const { currentPassword, password, passwordConfirmation } =
      passwordCombination;

    let data: any = {
      password,
      password_confirmation: passwordConfirmation,
    };

    if (currentPassword) {
      data = {
        ...data,
        current_password: currentPassword,
      };
    }

    return this.http
      .patch<MessageResponse>(`${this.url}/user/reset/${id}`, data)
      .pipe(map(() => 'Your password has been successfully updated.'));
  }

  resetPassword(passwordCombination: PasswordCombination): Observable<string> {
    const { password, passwordConfirmation } = passwordCombination;
    let data: any = {
      password,
      password_confirmation: passwordConfirmation,
    };

    return this.http
      .put<MessageResponse>(`${this.url}/password`, data)
      .pipe(map((resp) => resp.message));
  }

  // Confirmation

  resendConfirmation(email: string): Observable<string> {
    return this.http
      .post<MessageResponse>(`${this.url}/user/confirmation`, {
        email,
      })
      .pipe(map((resp) => resp.message));
  }

  // Session

  getUser(): Observable<User> {
    return this.http
      .get<UserDataResponse>(`${this.url}/user`)
      .pipe(map((resp) => resp.data));
  }

  getUserById(id:number){
    return this.http.get(`${this.url}/user/get/${id}`)
  }

  login(credentials: Credentials): Observable<User> {
    return this.http
      .post<any>(`${this.url}/auth/login`, { username: credentials.email, password: credentials.password })
  }

  logout(): Observable<any> {
    return this.http.delete(`${this.url}/sign_out`);
  }
}
