import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import {
  AccountPageActions,
  AuthActions,
  CreateAccountPageActions,
  ForgotPasswordPageActions,
  LoginPageActions,
  ResendConfirmationPageActions,
  ResetPasswordPageActions,
} from '../actions';
import {
  CreateAccountRequest,
  Credentials,
  PasswordCombination,
  User,
} from '../models';
import * as fromAuth from '../reducers';

@Injectable({ providedIn: 'root' })
export class AuthFacadeService {
  isUserAdmin$: Observable<boolean>;
  loggedIn$: Observable<boolean>;
  user$: Observable<any>;

  constructor(private store: Store<fromAuth.State>) {
    this.isUserAdmin$ = this.store.pipe(select(fromAuth.selectIsAdmin));
    this.loggedIn$ = this.store.pipe(select(fromAuth.selectLoggedIn));
    this.user$ = this.store.pipe(select(fromAuth.selectUser));
  }

  createAccount(account: CreateAccountRequest): void {
    this.store.dispatch(CreateAccountPageActions.createAccount({ account }));
  }

  deleteAccount(id: number): void {
    this.store.dispatch(AuthActions.deleteAccount({ id }));
  }

  deleteAccountConfirmation(id: number): void {
    this.store.dispatch(AccountPageActions.deleteAccountConfirmation({ id }));
  }

  forgotPassword(email: string): void {
    this.store.dispatch(ForgotPasswordPageActions.forgotPassword({ email }));
  }

  login(credentials: Credentials): void {
    this.store.dispatch(LoginPageActions.login({ credentials }));
  }

  logout(): void {
    this.store.dispatch(AuthActions.logout());
  }

  loadUser(): void {
    this.store.dispatch(AuthActions.loadUser());
  }

  resendConfirmation(email: string): void {
    this.store.dispatch(
      ResendConfirmationPageActions.resendConfirmation({ email })
    );
  }

  resetPassword(passwordCombination: PasswordCombination, id: number): void {
    this.store.dispatch(
      ResetPasswordPageActions.resetPassword({ passwordCombination, id })
    );
  }

  showConfirmationAccountMessage(message: string): void {
    this.store.dispatch(
      LoginPageActions.showAccountConfirmationMessage({
        message,
      })
    );
  }

  updateAccount(user: User, id: number): void {
    this.store.dispatch(AccountPageActions.updateAccount({ user, id }));
  }

  updatePassword(passwordCombination: PasswordCombination, id: number): void {
    this.store.dispatch(
      AccountPageActions.updatePassword({ passwordCombination, id })
    );
  }
}
