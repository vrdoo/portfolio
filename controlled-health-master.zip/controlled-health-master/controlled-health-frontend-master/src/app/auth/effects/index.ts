import { AuthEffects } from './auth.effect';

export const effects: any[] = [AuthEffects];

export * from './auth.effect';
