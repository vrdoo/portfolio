import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { catchError, exhaustMap, map, switchMap, tap } from 'rxjs/operators';
import { MessageApiActions, UserActions } from '../../core/actions';
import { ErrorsService } from '../../shared/services/errors.service';
import {
  AccountPageActions,
  AuthActions,
  AuthApiActions,
  CreateAccountPageActions,
  ForgotPasswordPageActions,
  LoginPageActions,
  ResendConfirmationPageActions,
  ResetPasswordPageActions,
} from '../actions';
import { DeleteAccountConfirmationComponent } from '../componentes';
import { AuthService } from '../services/auth.service';
import { TokenInterceptor } from '../interceptors/token.interceptor';
import { AccountsService } from 'src/app/accounts/services/accounts.service';
import { User } from '../models';

@Injectable()
export class AuthEffects {


  createAccount$ = createEffect(() =>
    this.actions$.pipe(
      ofType(CreateAccountPageActions.createAccount),
      exhaustMap(({ account }) =>
        this.authService.createAccount(account).pipe(
          switchMap((message) => [
            AuthApiActions.loginRedirect(),
            MessageApiActions.successMessage({
              message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  updateAccount$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AccountPageActions.updateAccount),
      exhaustMap(({ user, id }) =>
        this.authService.updateAccount(user, id).pipe(
          switchMap((resp) => [
            AuthApiActions.updateAccountSuccess({ user: resp.data }),
            MessageApiActions.successMessage({
              message: resp.message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  updatePassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AccountPageActions.updatePassword),
      exhaustMap(({ passwordCombination, id }) =>
        this.authService.updatePassword(passwordCombination, id).pipe(
          switchMap((message) => [
            MessageApiActions.successMessage({
              message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  deleteAccountConfirmation$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AccountPageActions.deleteAccountConfirmation),
      exhaustMap(({ id }): any => {
        const dialogRef = this.dialog.open<
          DeleteAccountConfirmationComponent,
          undefined,
          boolean
        >(DeleteAccountConfirmationComponent);


        return dialogRef.afterClosed()
      }),

      map((result) => {
        const id = localStorage.getItem("uId")
        return result
          ? AuthActions.deleteAccount({ id: id ? +id : 0 })
          : AuthActions.deleteAccountConfirmationDismiss({ id: id ? +id : 0 })
      }
      )
    )
  );

  deleteAccount$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.deleteAccount),
      exhaustMap(({ id }) =>
        this.authService.deleteAccount(id).pipe(
          switchMap((message) => [
            AuthActions.logout(),
            MessageApiActions.successMessage({
              message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  showAccountConfirmationMessage$ = createEffect(() =>
    this.actions$.pipe(
      ofType(LoginPageActions.showAccountConfirmationMessage),
      map(({ message }) =>
        MessageApiActions.successMessage({
          message,
        })
      )
    )
  );

  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(LoginPageActions.login),
      exhaustMap(({ credentials }) =>
        this.authService.login(credentials).pipe(
          map((data: any) => {
            if (data.access_token) {
              localStorage.setItem("access-token", data.access_token)
              localStorage.setItem("client", data.user.username)
              localStorage.setItem("uId", data.user.id)
            }
            return AuthApiActions.loginSuccess({
              user: data.user,
            })
          }
          ),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  loginSuccess$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthApiActions.loginSuccess),
        tap(() => {
          const token = localStorage.getItem("access-token")
          if (token) {
            return this.router.navigate(['/profiles'])
          } else {
            return this.router.navigate(['/login'])
          }
        }
        )
      ),
    { dispatch: false }
  );

  logoutIdleUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserActions.idleTimeout),
      map(() => {
        return AuthActions.logout()
      })
    )
  );

  logout$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.logout),
      exhaustMap(() => {
        return this.authService.logout().pipe(
          tap(() => localStorage.clear()),
          map(() => AuthApiActions.loginRedirect()),
          catchError(() => of(AuthApiActions.loginRedirect()))
        )
      }

      )
    )
  );

  loadUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.loadUser),
      exhaustMap(() =>
        this.authService.getUser().pipe(
          map((user) => {
            return AuthApiActions.loadUserSuccess({
              user:{},
            })
          }
          ),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  forgotPassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ForgotPasswordPageActions.forgotPassword),
      exhaustMap(({ email }) =>
        this.authService.forgotPassword(email).pipe(
          switchMap((message) => [
            AuthApiActions.loginRedirect(),
            MessageApiActions.successMessage({
              message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  resetPassword$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ResetPasswordPageActions.resetPassword),
      exhaustMap(({ passwordCombination, id }) =>
        this.authService.resetPassword(passwordCombination).pipe(
          switchMap((message) => [
            AuthApiActions.loginRedirect(),
            MessageApiActions.successMessage({
              message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  resendConfirmation$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ResendConfirmationPageActions.resendConfirmation),
      exhaustMap(({ email }) =>
        this.authService.resendConfirmation(email).pipe(
          switchMap((message) => [
            AuthApiActions.loginRedirect(),
            MessageApiActions.successMessage({
              message,
            }),
          ]),
          catchError((error) => this.errorService.showError(error))
        )
      )
    )
  );

  loginRedirect$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthApiActions.loginRedirect),
        tap(() => {
          {
            return this.router.navigate(['/login'])
          }
        })
      ),
    { dispatch: false }
  );

  private token!: TokenInterceptor

  constructor(
    private actions$: Actions,
    private authService: AuthService,
    private dialog: MatDialog,
    private errorService: ErrorsService,
    private router: Router,
    private accountsService: AccountsService,
  ) { }
}
