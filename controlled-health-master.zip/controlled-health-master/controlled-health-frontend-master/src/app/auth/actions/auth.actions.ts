import { createAction, props } from '@ngrx/store';

export const deleteAccount = createAction('[Auth] Delete Account',props<{id:number}>());

export const deleteAccountConfirmationDismiss = createAction(
  '[Auth] Delete Account Confirmation Dismiss',
  props<{id:number}>()
);

export const loadUser = createAction('[Auth Guard] Load User');

export const logout = createAction('[Auth] Logout');
