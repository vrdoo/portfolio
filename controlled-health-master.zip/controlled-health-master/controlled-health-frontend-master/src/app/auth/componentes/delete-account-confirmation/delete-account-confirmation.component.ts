import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  templateUrl: './delete-account-confirmation.component.html',
  styleUrls: ['./delete-account-confirmation.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DeleteAccountConfirmationComponent {}
