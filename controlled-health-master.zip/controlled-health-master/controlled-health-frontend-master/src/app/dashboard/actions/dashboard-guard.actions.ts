import { createAction } from '@ngrx/store';

export const loadDashboardGuard = createAction(
  '[Dashboard Guard] Load Dashboard'
);
