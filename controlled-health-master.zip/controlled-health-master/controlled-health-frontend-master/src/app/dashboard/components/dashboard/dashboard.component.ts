import { ChangeDetectionStrategy, Component, Input, OnChanges } from '@angular/core';
import { Dashboard } from '../../models';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DashboardComponent implements OnChanges {
  @Input() dashboard?: Dashboard;


  ngOnChanges() { }
}
