import { DashboardComponent } from './dashboard/dashboard.component';

export const components: any[] = [DashboardComponent];

export * from './dashboard/dashboard.component';
