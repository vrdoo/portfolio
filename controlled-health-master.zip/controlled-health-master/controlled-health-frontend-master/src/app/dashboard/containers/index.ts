import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';

export const containers: any[] = [
  DashboardPageComponent,
];

export * from './dashboard-page/dashboard-page.component';
