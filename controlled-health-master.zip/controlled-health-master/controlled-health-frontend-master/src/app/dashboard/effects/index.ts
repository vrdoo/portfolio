import { DashboardEffects } from './dashboard.effects';

export const effects: any[] = [DashboardEffects];

export * from './dashboard.effects';
