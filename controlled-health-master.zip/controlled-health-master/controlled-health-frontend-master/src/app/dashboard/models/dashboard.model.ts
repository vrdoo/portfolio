import { Height, Weight } from '../../core/models';

export interface Dashboard {
  heights: Height[];
  weights: Weight[];
}
