import { createAction } from '@ngrx/store';

export const loadWeights = createAction('[Weights Guard] Load Weights');
