import { createAction } from '@ngrx/store';

export const weightFormDialogDismiss = createAction(
  '[Weights] Weight Form Dialog Dismiss'
);

export const loadDashboard = createAction('[Weights] Load Dashboard');
