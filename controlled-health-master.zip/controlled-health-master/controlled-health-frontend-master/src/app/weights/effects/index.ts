import { WeightsEffects } from './weights.effects';

export const effects: any[] = [WeightsEffects];

export * from './weights.effects';
