export * from './weight-response.model';
