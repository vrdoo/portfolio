import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Sort } from '@angular/material/sort';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ExamResult, ExamResultResponse } from '../models';

@Injectable()
export class ExamsResultsService {
  constructor(private http: HttpClient) {}

  create(examResult: ExamResult, resultId: number): Observable<ExamResult> {
    return this.http.post<ExamResult>(
      `${environment.baseUrl}/results`,
      { value: examResult.value, examId: examResult.exam.id }
    );
  }

  delete(id: number, resultId: number): Observable<any> {
    console.log("id==>",id)
    console.log("resId==>",resultId);
    
    
    return this.http.delete<any>(
      `${environment.baseUrl}/results/${resultId}`
    );
  }

  getAll(
    id: number,
    pageIndex: number,
    sort: Sort
  ): Observable<ExamResultResponse> {
    const params = new HttpParams()
      .set('page', pageIndex.toString())
      .set('sort', sort.active)
      .set('dir', sort.direction);

    return this.http.get<ExamResultResponse>(
      `${environment.baseUrl}/results`,
      {
        params,
      }
    );
  }

  update(examResult: ExamResult, resultId: number): Observable<ExamResult> {
    console.log("resId===>",resultId);
    
    return this.http.patch<ExamResult>(
      `${environment.baseUrl}/results/${resultId}`,
      { value: examResult.value, examId: examResult.exam.id }
    );
  }
}
