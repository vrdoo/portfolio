import { createAction } from '@ngrx/store';

export const loadAllExams = createAction(
  '[All Exams Exist Guard] Load All Exams'
);
