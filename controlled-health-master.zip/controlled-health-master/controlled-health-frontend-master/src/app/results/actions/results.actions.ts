import { createAction } from '@ngrx/store';

export const resultFormDialogDismiss = createAction(
  '[Results] Result Form Dialog Dismiss'
);
