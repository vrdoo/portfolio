import { createAction } from '@ngrx/store';

export const loadResults = createAction('[Results Guard] Load Results');
