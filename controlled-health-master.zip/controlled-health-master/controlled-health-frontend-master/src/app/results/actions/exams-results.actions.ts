import { createAction } from '@ngrx/store';

export const examResultFormDialogDismiss = createAction(
  '[Exams Results] Exam Result Form Dialog Dismiss'
);
