export interface Result {
  id: number;
  date: string;
  description: string;
}
