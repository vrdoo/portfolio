export * from './exam-graphic.model';
export * from './exam-result-delete-event.model';
export * from './exam-result-request.model';
export * from './exam-result-response.model';
export * from './exam-result.model';
export * from './result-response.model';
export * from './result.model';
export * from './unit.model';
