export interface Unit {
  id: number;
  name: string;
}
