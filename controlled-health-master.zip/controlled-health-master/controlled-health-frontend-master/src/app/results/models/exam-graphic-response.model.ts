import { ExamGraphic } from '.';

export interface ExamGraphicResponse {
  exam_results: ExamGraphic[];
}
