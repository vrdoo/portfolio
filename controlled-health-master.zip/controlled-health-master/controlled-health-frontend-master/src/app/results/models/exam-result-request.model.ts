import { ExamResult } from '.';

export interface ExamResultRequest {
  examResult: ExamResult;
  resultId: number;
}
