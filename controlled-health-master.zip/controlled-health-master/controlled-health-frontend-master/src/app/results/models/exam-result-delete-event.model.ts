export interface ExamResultDeleteEvent {
  id: number;
  resultId: number;
}
