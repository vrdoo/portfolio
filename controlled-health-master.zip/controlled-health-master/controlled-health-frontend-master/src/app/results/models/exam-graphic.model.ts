export interface ExamGraphic {
  id: number;
  date: string;
  description: string;
  result_id: number;
  value: number;
}
