import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from '../../models';
import { AccountsFacadeService } from '../../services/accounts-facade.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-accounts-page',
  templateUrl: './accounts-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AccountsPageComponent implements OnInit {
  accounts$: Observable<Account[]>;
  accountSelected$: Observable<Account | null>;
  accountSelectedLoaded$: Observable<boolean>;

  constructor(private accountsFacadeService: AccountsFacadeService, private router: Router) {
    this.accounts$ = this.accountsFacadeService.accounts$;
    this.accountSelected$ = this.accountsFacadeService.selected$;
    this.accountSelectedLoaded$ = this.accountsFacadeService.selectedLoaded$;
  }

  ngOnInit(): void {
    this.getAccountSelected();
  }
  getAccountSelected() {
    const account = localStorage.getItem('uId');

    if (!!account) {
      this.accountsFacadeService.loadAccount(+account);
    }
  }

  onAdd(): void {
    this.accountsFacadeService.add();
  }

  onDelete(id: number): void {
    this.accountsFacadeService.delete(id);
  }

  onEdit(account: Account): void {
    this.accountsFacadeService.edit(account);
  }

  onEnter(account: Account): void {
    this.accountsFacadeService.loadAccountFromPage(account);
  }
}
