import { AccountsEffects } from './accounts.effects';

export const effects: any[] = [AccountsEffects];

export * from './accounts.effects';
