import { createReducer, on } from '@ngrx/store';
import { AccountsActions, AccountsApiActions } from '../actions';
import { Account } from '../models';
import { deleteAccount, deleteAccountSuccess } from '../actions/accounts-page.actions';

export const accountsFeatureKey = 'accounts';

export interface State {
  list: Account[];
  listLoaded: boolean;
  selected: Account | null;
}

export const initialState: State = {
  list: [],
  listLoaded: false,
  selected: null,
};

export const reducer = createReducer(
  initialState,

  on(
    AccountsActions.loadAccountFromPageSuccess,
    AccountsApiActions.loadAccountSuccess,
    (state, { account }) => ({
      ...state,
      selected: { ...state.list, ...account },
    })
  ),

  on(AccountsApiActions.loadAccountsSuccess, (state, { accountResponse }) => ({
    ...state,
    list: accountResponse,
    listLoaded: true,
  })),

  on(AccountsActions.loadAccountFromUpdateSuccess, deleteAccountSuccess, (state, { account }) => ({
    ...state,
    list: account
  }))
);

export const getList = (state: State) => state.list;
export const getListLoaded = (state: State) => state.listLoaded;
export const getSelected = (state: State) => state.selected;
export const getSelectedLoaded = (state: State) => !!state.selected;