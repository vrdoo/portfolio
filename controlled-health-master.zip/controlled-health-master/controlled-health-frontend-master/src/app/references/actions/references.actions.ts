import { createAction } from '@ngrx/store';

export const referenceFormDialogDismiss = createAction(
  '[References] Reference Form Dialog Dismiss'
);
