import { createAction } from '@ngrx/store';

export const loadReferences = createAction('[References Guard] Load References');
