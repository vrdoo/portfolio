import { ReferencesEffects } from './references.effects';

export const effects: any[] = [ReferencesEffects];

export * from './references.effects';
