import { createAction } from '@ngrx/store';

export const loadExams = createAction('[Exams Guard] Load Exams');
