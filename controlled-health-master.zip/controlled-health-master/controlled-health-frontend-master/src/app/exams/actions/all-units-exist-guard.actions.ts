import { createAction } from '@ngrx/store';

export const loadAllUnits = createAction(
  '[All Units Exist Guard] Load All Units'
);
