import { createAction } from '@ngrx/store';

export const examFormDialogDismiss = createAction(
  '[Exams] Exam Form Dialog Dismiss'
);
