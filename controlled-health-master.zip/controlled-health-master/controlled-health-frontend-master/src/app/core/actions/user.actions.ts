import { createAction } from '@ngrx/store';

export const idleTimeout = createAction('[User] Idle Timeout');
