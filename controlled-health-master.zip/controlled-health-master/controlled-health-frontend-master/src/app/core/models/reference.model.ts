import { BaseResourceModel } from './base-resource.model';

export interface Reference extends BaseResourceModel {
  name: string;
}
