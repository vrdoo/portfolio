import { Unit } from './unit.model';

export interface Exam {
  id: number;
  name: string;
  unit: Unit;
}
