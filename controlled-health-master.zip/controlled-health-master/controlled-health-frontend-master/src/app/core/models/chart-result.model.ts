import { Serie } from './serie.model';

export interface ChartResult {
  name: string;
  series: Serie[];
}
