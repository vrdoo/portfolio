import { BaseResourceModel } from './base-resource.model';

export interface Unit extends BaseResourceModel {
  name: string;
}
