export interface DialogData {
  cancelText?: string;
  confirmText?: string;
  content: string;
  title: string;
}
