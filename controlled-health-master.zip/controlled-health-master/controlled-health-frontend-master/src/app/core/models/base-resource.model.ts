export interface BaseResourceModel {
  id: number;
}
