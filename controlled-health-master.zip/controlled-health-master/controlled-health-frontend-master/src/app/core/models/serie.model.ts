export interface Serie {
  name: Date;
  value: number;
  min?: number;
  max?: number;
}
