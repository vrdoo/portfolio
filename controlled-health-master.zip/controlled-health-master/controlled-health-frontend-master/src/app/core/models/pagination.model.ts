export interface Pagination {
  currentPage: number;
  totalItems: number;
  itemsPerPage: number;
}