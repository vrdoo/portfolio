import { createAction } from '@ngrx/store';

export const loadHeights = createAction('[Heights Guard] Load Heights');
