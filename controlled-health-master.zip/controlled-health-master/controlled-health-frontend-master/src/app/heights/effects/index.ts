import { HeightsEffects } from './heights.effects';

export const effects: any[] = [HeightsEffects];

export * from './heights.effects';
