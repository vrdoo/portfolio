import { createAction } from '@ngrx/store';

export const loadUnits = createAction('[Units Guard] Load Units');
