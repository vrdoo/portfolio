import { createAction } from '@ngrx/store';

export const unitFormDialogDismiss = createAction(
  '[Units] Unit Form Dialog Dismiss'
);
