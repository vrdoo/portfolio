import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { PageEvent } from '@angular/material/paginator';
import { Sort } from '@angular/material/sort';
import { Observable } from 'rxjs';
import { Pagination, Unit } from '../../../core/models';
import { UnitsFacadeService } from '../../services/units-facade.service';
import { Store } from '@ngrx/store';
import { loadUnits } from '../../actions/units-guard.actions';

@Component({
  selector: 'app-units-page',
  templateUrl: './units-page.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UnitsPageComponent implements OnInit {
  units$: Observable<Unit[]>;
  pagination$: Observable<Pagination>;
  sort$: Observable<Sort>;

  constructor(private unitsFacadeService: UnitsFacadeService,private store:Store) {
    this.units$ = this.unitsFacadeService.units$;
    this.pagination$ = this.unitsFacadeService.pagination$;
    this.sort$ = this.unitsFacadeService.sort$;
  }


  ngOnInit(){
    this.store.dispatch(loadUnits())
  }

  onAdd(): void {
    this.unitsFacadeService.add();
  }

  onChangePage(event: PageEvent): void {
    this.unitsFacadeService.changePage(event.pageIndex + 1);
  }

  onDelete(id: number): void {
    this.unitsFacadeService.delete(id);
  }

  onEdit(unit: Unit): void {
    this.unitsFacadeService.edit(unit);
  }

  onSortEvent(sort: Sort) {
    this.unitsFacadeService.sort(sort);
  }
}
