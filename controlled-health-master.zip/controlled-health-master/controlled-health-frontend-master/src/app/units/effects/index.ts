import { UnitsEffects } from './units.effects';

export const effects: any[] = [UnitsEffects];

export * from './units.effects';
