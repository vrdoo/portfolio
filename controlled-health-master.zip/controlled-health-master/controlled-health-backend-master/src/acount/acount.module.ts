import { Module } from '@nestjs/common';
import { AcountService } from './acount.service';
import { AcountController } from './acount.controller';
import { Acount } from './entities/acount.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports :[TypeOrmModule.forFeature([Acount])],
  controllers: [AcountController],
  providers: [AcountService],
  exports:[AcountService]
})
export class AcountModule {}
