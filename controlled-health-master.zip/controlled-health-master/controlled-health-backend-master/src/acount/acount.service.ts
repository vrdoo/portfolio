import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateAcountDto } from './dto/create-acount.dto';
import { UpdateAcountDto } from './dto/update-acount.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Acount } from './entities/acount.entity';
import { Repository } from 'typeorm';

@Injectable()
export class AcountService {
  constructor(
    @InjectRepository(Acount) private acountRepository: Repository<Acount>,
  ) { }

  async create(createAcountDto: CreateAcountDto) {
    return await this.acountRepository.save(createAcountDto)

  }

  async findAll() {
    const acounts = await this.acountRepository.find()
    if (acounts) {
      return acounts;
    } else {
      throw new UnauthorizedException("we don't have acounts")
    }
  }

  async findOne(id: number) {
    const ac = await this.acountRepository.findOneBy({ id })
    if (ac) {
      return ac
    } else {
      throw new UnauthorizedException("acount not found")
    }
  }

  async update(id: number, updateAcountDto: UpdateAcountDto) {
    const account = await this.acountRepository.findOneBy({ id })
    if (account) {
      const acount = await this.acountRepository.update(id, updateAcountDto)
      const accounts=await this.acountRepository.find()
      return accounts
    } else {
      throw new UnauthorizedException("Account not found")
    }
  }

  async remove(id: number) {
    const account = await this.acountRepository.findOneBy({ id })
    if (account) {
      const deletes = await this.acountRepository.delete(id)
       return await this.acountRepository.find()
    } else {
      throw new UnauthorizedException("Account not found")
    }
  }
}
