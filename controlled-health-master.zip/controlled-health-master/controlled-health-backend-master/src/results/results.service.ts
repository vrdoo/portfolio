import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateResultDto } from './dto/create-result.dto';
import { UpdateResultDto } from './dto/update-result.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Result } from './entities/result.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ResultsService {

  constructor(
    @InjectRepository(Result) private resRepository: Repository<Result>,
  ) { }

  async create(createResultDto: CreateResultDto) {
    return await this.resRepository.save(createResultDto)
  }

  async findAll() {
    return await this.resRepository.find({
      relations: [
        "exam", "exam.unit"
      ]
    })
  }

  async findOne(id: number) {
    const res = await this.resRepository.findOne({ 
      where:{
        id
      },
      relations:[
        "exam","exam.unit"
      ]
     })
    if (res) {
      return res
    } else {
      throw new UnauthorizedException("results not found")
    }

  }

  async update(id: number, updateResultDto: UpdateResultDto) {
    const res = await this.resRepository.findOneBy({ id })
    const {value,description,examId}=updateResultDto
    if (res) {
      return await this.resRepository.update(id, {value,description,examId})
    } else {
      throw new UnauthorizedException("results not found")
    }
  }

  async remove(id: number) {
    const res = await this.resRepository.findOneBy({ id })
    if (res) {
      return await this.resRepository.delete(id)
    } else {
      throw new UnauthorizedException("results not found")
    }
  }
}
