export class CreateResultDto {}
