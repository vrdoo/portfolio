import { Exam } from 'src/exam/entities/exam.entity';
import { Range } from 'src/range/entities/range.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Result {
    @PrimaryGeneratedColumn()
    id: number;

    @Column({nullable:true})
    value: number

    @Column("int",{nullable:true})
    examId:number

    @Column("text",{nullable:true})
    description:string


    @ManyToOne(type=>Exam,exams=>exams.results,{
        onDelete:"CASCADE",
        onUpdate:"CASCADE"
    })
    exam:Exam
}