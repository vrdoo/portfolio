import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateHeightDto } from './dto/create-height.dto';
import { UpdateHeightDto } from './dto/update-height.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Height } from './entities/height.entity';
import { Repository } from 'typeorm';

@Injectable()
export class HeightsService {
  constructor(
    @InjectRepository(Height) private heigthRepository: Repository<Height>,
  ) {}

async  create(createHeightDto: CreateHeightDto) {
    return await this.heigthRepository.save(createHeightDto);
  }

 async findAll() {
    return await this.heigthRepository.find();
  }

 async findOne(id: number) {
  const heigth= await this.heigthRepository.findOneBy({id})
  if(heigth){
    return heigth
  }else{
    throw new UnauthorizedException("hegth not found")
  }
  }

 async update(id: number, updateHeightDto: UpdateHeightDto) {
    const heigth= await this.heigthRepository.findOneBy({id})
  if(heigth){
    return await this.heigthRepository.update(id,updateHeightDto)
  }else{
    throw new UnauthorizedException("hegth not found")
  }
  }

 async remove(id: number) {
    const heigth= await this.heigthRepository.findOneBy({id})
    if(heigth){
      return await this.heigthRepository.delete(id)
    }else{
      throw new UnauthorizedException("hegth not found")
    }
  }
}
