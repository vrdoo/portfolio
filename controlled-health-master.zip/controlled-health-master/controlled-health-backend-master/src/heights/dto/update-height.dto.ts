import { PartialType } from '@nestjs/mapped-types';
import { CreateHeightDto } from './create-height.dto';

export class UpdateHeightDto extends PartialType(CreateHeightDto) {}
