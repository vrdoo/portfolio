import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { HeightsService } from './heights.service';
import { CreateHeightDto } from './dto/create-height.dto';
import { UpdateHeightDto } from './dto/update-height.dto';

@Controller('heights')
export class HeightsController {
  constructor(private readonly heightsService: HeightsService) {}

  @Post()
  create(@Body() createHeightDto: CreateHeightDto) {
    return this.heightsService.create(createHeightDto);
  }

  @Get()
  findAll() {
    return this.heightsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.heightsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateHeightDto: UpdateHeightDto) {
    return this.heightsService.update(+id, updateHeightDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.heightsService.remove(+id);
  }
}
