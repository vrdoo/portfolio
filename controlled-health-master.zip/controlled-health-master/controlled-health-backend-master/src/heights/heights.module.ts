import { Module } from '@nestjs/common';
import { HeightsService } from './heights.service';
import { HeightsController } from './heights.controller';
import { Height } from './entities/height.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports :[TypeOrmModule.forFeature([Height])],
  controllers: [HeightsController],
  providers: [HeightsService]
})
export class HeightsModule {}
