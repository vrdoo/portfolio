import { Test, TestingModule } from '@nestjs/testing';
import { HeightsService } from './heights.service';

describe('HeightsService', () => {
  let service: HeightsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [HeightsService],
    }).compile();

    service = module.get<HeightsService>(HeightsService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
