import { Test, TestingModule } from '@nestjs/testing';
import { HeightsController } from './heights.controller';
import { HeightsService } from './heights.service';

describe('HeightsController', () => {
  let controller: HeightsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [HeightsController],
      providers: [HeightsService],
    }).compile();

    controller = module.get<HeightsController>(HeightsController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
