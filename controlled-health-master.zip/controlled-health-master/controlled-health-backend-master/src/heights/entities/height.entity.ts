import { Dashboard } from 'src/dashboard/entities/dashboard.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Height {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    value:number

    @Column()
    date:string

    @OneToMany(type=>Dashboard,dash=>dash.heights)
    dashboard:Dashboard
}