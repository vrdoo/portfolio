import { Injectable } from '@nestjs/common';
import { CreateExamDto } from './dto/create-exam.dto';
import { UpdateExamDto } from './dto/update-exam.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Exam } from './entities/exam.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ExamService {

  constructor(
    @InjectRepository(Exam) private examRepository: Repository<Exam>,
  ) { }

  async create(createExamDto: CreateExamDto) {
    return await this.examRepository.save(createExamDto);
  }

  async findAll() {
    return await this.examRepository.find({
      relations:[
        "unit"
      ]
    });
  }

  async findOne(id: number) {
    return await this.examRepository.findOneBy({ id });
  }

  async update(id: number, updateExamDto: UpdateExamDto) {
    return await this.examRepository.update(id, updateExamDto);
  }

  async remove(id: number) {
    return await this.examRepository.delete(id);
  }
}
