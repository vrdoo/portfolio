export class CreateExamDto {}
