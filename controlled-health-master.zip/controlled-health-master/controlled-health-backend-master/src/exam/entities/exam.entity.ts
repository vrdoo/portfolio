import { Result } from "src/results/entities/result.entity";
import { Unit } from "src/unit/entities/unit.entity";
import { Column, Entity, ManyToMany, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";


@Entity()
export class Exam {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string

    @Column({nullable:true})
    ancestry:string

    @Column("int",{nullable:true})
    unitId:number

    @ManyToOne(type=>Unit,unit=>unit.exam,{
        onDelete:"CASCADE",
        onUpdate:"CASCADE"
    })
    unit:Unit

    @OneToMany(type=>Result,res=>res.exam)
    results:Result
}