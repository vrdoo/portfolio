import { Body, Controller, Get, HttpStatus, Post, Request, Res, UseGuards, Param, Delete } from '@nestjs/common';
import { AppService } from './app.service';
import { AuthService } from './auth/auth.service';
import { UserService } from './user/user.service';
import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { LocalAuthGuard } from './auth/local-auth.guard';
import { Response } from 'express';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService, private readonly userSerevice: UserService,
    private authService: AuthService) { }

  @UseGuards(LocalAuthGuard)
  @Post('auth/login')
  async login(@Request() req) {
    console.log(req);
    return (await this.authService.login(req.user))
  }


  @UseGuards(JwtAuthGuard)
  @Get('account')
  async getProfile(@Request() req, @Res() res: Response) {
    try {
      const data = await this.userSerevice.findOne(req.user.username)
      return res.status(HttpStatus.OK).json({ user: data })
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({
        error: e.message
      })
    }
  }

  @Get('accounts/:id')
  async findOneById(@Param('id') id: number, @Res() res: Response) {
    try {
      const data = await this.userSerevice.findOneById(id)
      return res.status(HttpStatus.OK).json(data)

    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ message: e.message })
    }
  }


  @Delete('sign_out')
  remove() {
    console.log("log out");
  }
}
