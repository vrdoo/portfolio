import { Weight } from 'src/weights/entities/weight.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Range {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    min:number

    @Column()
    max:number

    @OneToMany(type=>Weight,wg=>wg.range)
    weight:Weight
}