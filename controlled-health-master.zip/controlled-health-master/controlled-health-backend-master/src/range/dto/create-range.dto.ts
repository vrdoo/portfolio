export class CreateRangeDto {}
