import { Injectable } from '@nestjs/common';
import { CreateRangeDto } from './dto/create-range.dto';
import { UpdateRangeDto } from './dto/update-range.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Range } from './entities/range.entity';
import { Repository } from 'typeorm';

@Injectable()
export class RangeService {

  constructor(
    @InjectRepository(Range) private rangeRepository: Repository<Range>,
  ) { }

 async create(createRangeDto: CreateRangeDto) {
    return await this.rangeRepository.save(createRangeDto);
  }

 async findAll() {
    return this.rangeRepository.find()
  }

  findOne(id: number) {
    return `This action returns a #${id} range`;
  }

async  update(id: number, updateRangeDto: UpdateRangeDto) {
    return await this.rangeRepository.update(id,updateRangeDto)
  }

 async remove(id: number) {
    return await this.rangeRepository.delete(id)
  }
}
