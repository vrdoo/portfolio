import { Module } from '@nestjs/common';
import { RangeService } from './range.service';
import { RangeController } from './range.controller';
import { Range } from './entities/range.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports :[TypeOrmModule.forFeature([Range])],
  controllers: [RangeController],
  providers: [RangeService]
})
export class RangeModule {}
