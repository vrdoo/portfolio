import { Injectable } from '@nestjs/common';
import { CreateReferenceDto } from './dto/create-reference.dto';
import { UpdateReferenceDto } from './dto/update-reference.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Reference } from './entities/reference.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ReferenceService {

  constructor(
    @InjectRepository(Reference) private referenceRepository: Repository<Reference>,
  ) { }

 async create(createReferenceDto: CreateReferenceDto) {
    return await this.referenceRepository.save(createReferenceDto);
  }

 async findAll() {
    return await this.referenceRepository.find();
  }

 async findOne(id: number) {
    return await this.referenceRepository.findOneBy({id});
  }

 async update(id: number, updateReferenceDto: UpdateReferenceDto) {
    return await this.referenceRepository.update(id,updateReferenceDto);
  }

 async remove(id: number) {
    return await this.referenceRepository.delete(id);
  }
}
