export class CreateReferenceDto {}
