import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { User } from './user/entities/user.entity';
import { UnitModule } from './unit/unit.module';
import { ReferenceModule } from './reference/reference.module';
import { ExamModule } from './exam/exam.module';
import { Exam } from './exam/entities/exam.entity';
import { Reference } from './reference/entities/reference.entity';
import { Unit } from './unit/entities/unit.entity';
import { UserModule } from './user/user.module';
import { AcountModule } from './acount/acount.module';
import { Acount } from './acount/entities/acount.entity';
import { DashboardModule } from './dashboard/dashboard.module';
import { HeightsModule } from './heights/heights.module';
import { WeightsModule } from './weights/weights.module';
import { ResultsModule } from './results/results.module';
import { RangeModule } from './range/range.module';
import { Weight } from './weights/entities/weight.entity';
import { Height } from './heights/entities/height.entity';
import { Result } from './results/entities/result.entity';
import { Range } from './range/entities/range.entity';
import { Dashboard } from './dashboard/entities/dashboard.entity';

@Module({
  imports: [AuthModule,
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '',
      database: 'health',
      entities: [
        User, Exam,
        Reference,
        Unit, Acount,
        Weight, Height,
        Result, Range,
        Dashboard],
      synchronize: true,
    }),
    UnitModule,
    ReferenceModule,
    ExamModule,
    UserModule,
    AcountModule,
    DashboardModule,
    HeightsModule,
    WeightsModule,
    ResultsModule,
    RangeModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
