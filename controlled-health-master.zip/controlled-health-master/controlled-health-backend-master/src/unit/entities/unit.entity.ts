import { Exam } from 'src/exam/entities/exam.entity';
import { User } from 'src/user/entities/user.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Unit {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string

    @OneToMany(type=>Exam,exam=>exam.unit)
    exam:Exam[]

}