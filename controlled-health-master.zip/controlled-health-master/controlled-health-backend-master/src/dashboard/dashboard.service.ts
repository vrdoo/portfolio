import { Injectable } from '@nestjs/common';
import { CreateDashboardDto } from './dto/create-dashboard.dto';
import { UpdateDashboardDto } from './dto/update-dashboard.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Dashboard } from './entities/dashboard.entity';
import { Repository } from 'typeorm';

@Injectable()
export class DashboardService {

  constructor(
    @InjectRepository(Dashboard) private dashRepository: Repository<Dashboard>,
  ) { }

 async create(createDashboardDto: CreateDashboardDto) {
    return await this.dashRepository.save(createDashboardDto);
  }

 async findAll() {
    return await this.dashRepository.find({
      relations:[
        "heights","weights"
      ]
    })
  }

  findOne(id: number) {
    return `This action returns a #${id} dashboard`;
  }

  update(id: number, updateDashboardDto: UpdateDashboardDto) {
    return `This action updates a #${id} dashboard`;
  }

  remove(id: number) {
    return `This action removes a #${id} dashboard`;
  }
}
