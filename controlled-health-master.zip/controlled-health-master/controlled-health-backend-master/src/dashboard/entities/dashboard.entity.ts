import { Exam } from 'src/exam/entities/exam.entity';
import { Height } from 'src/heights/entities/height.entity';
import { Weight } from 'src/weights/entities/weight.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Dashboard {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("int")
    heightsId: number

    @Column("int")
    weightsId: number

    @ManyToOne(type=>Height,hg=>hg.dashboard,{
        onDelete:"CASCADE",
        onUpdate:"CASCADE"
    })
    heights:Height
    
    @ManyToOne(type=>Weight,wg=>wg.dashboards,{
        onDelete:"CASCADE",
        onUpdate:"CASCADE"
    })
    weights:Height
}