import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateWeightDto } from './dto/create-weight.dto';
import { UpdateWeightDto } from './dto/update-weight.dto';
import { Weight } from './entities/weight.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm'

@Injectable()
export class WeightsService {

  constructor(
    @InjectRepository(Weight) private weightRepository: Repository<Weight>,
  ) { }

 async create(createWeightDto: CreateWeightDto) {
    return await this.weightRepository.save(createWeightDto)
  }

 async findAll() {
    return await this.weightRepository.find({
      relations:["range"]
    })
  }

  async findOne(id: number) {
    const weight = await this.weightRepository.findOne({
      where: {
        id
      },
      relations:["range"]
    })
    if (weight) {
      return weight
    } else {
      throw new UnauthorizedException("weight not found")
    }
  }

  async update(id: number, updateWeightDto: UpdateWeightDto) {
    const weight = await this.weightRepository.findOneBy({ id })
    if (weight) {
      return await this.weightRepository.update(id, updateWeightDto)
    } else {
      throw new UnauthorizedException("weight not found")
    }
  }

  async remove(id: number) {
    const weight = await this.weightRepository.findOneBy({ id })
    if (weight) {
      return await this.weightRepository.delete(id)
    } else {
      throw new UnauthorizedException("weight not found")
    }
  }
}

