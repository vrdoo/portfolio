export class CreateWeightDto {}
