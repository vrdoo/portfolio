import { Dashboard } from 'src/dashboard/entities/dashboard.entity';
import { Range } from 'src/range/entities/range.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Weight {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    value:number

    @Column()
    date:string

    @Column("int",{nullable:true})
    rangeId:number

    @ManyToOne(type=>Range,range=>range.weight,{
        onDelete:"CASCADE",
        onUpdate:"CASCADE"
    })
    range:Range


    @OneToMany(type=>Dashboard,dash=>dash.weights)
    dashboards:Dashboard
}