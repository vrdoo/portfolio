import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    email: string;

    @Column()
    password: string;

    @Column({nullable:true})
    name:string

    @Column({nullable:true})
    gender:string

    @Column({nullable:true})
    date_of_birth:string

    @Column({default:false})
    admin:boolean

    @Column({default:false})
    verif:boolean
}