import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt'
import * as nodemailer from "nodemailer"

@Injectable()
export class UserService {

  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'vardanmargaryan56@gmail.com',
      pass: 'zxvahikmhkykonyv',
    },
  });

  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
  ) {

  }


  async create(createUserDto: CreateUserDto) {
    const user = await this.userRepository.findOne({
      where: {
        email: createUserDto.email
      }
    })
    if (user) {
      throw new UnauthorizedException("that email already had")
    } else {
      const { password, password_confirmation, ...body } = createUserDto
      if (password === password_confirmation) {
        const hash = await bcrypt.hash(password, 10)
        await this.userRepository.save({ ...body, password: hash });
        return true
      } else {
        throw new UnauthorizedException("password and password Confirmation must be the same")
      }
    }
  }

  async findAll() {
    return await this.userRepository.find();
  }

  async findOne(email: string) {
    const user = await this.userRepository.findOneBy({ email })
    if (!user) {
      throw new UnauthorizedException("user not found")
    } else if (!user.verif) {
      throw new UnauthorizedException("user must be passed the verification")
    } else {
      return user
    }
  }

  async findOneById(id: number) {
    const user = await this.userRepository.findOneBy({ id })
    if (!user) {
      throw new UnauthorizedException("user not found")
    } else {
      return user
    }
  }

  update(id: number, updateUserDto: UpdateUserDto) {
    return this.userRepository.update(id, updateUserDto);
  }

  async emailverif(email: string) {
    const user = await this.userRepository.findOneBy({ email })
    if (!user) {
      throw new UnauthorizedException("user not found")
    } else {
      const rand = Date.now().toString()
      const hash = await bcrypt.hash(rand, 10)
      this.transporter.sendMail({
        from: 'vardanmargaryan56@gmail.com',
        to: email,
        subject: "Change password ✔",
        text: "Your new password " + rand,

      },
      )
      const data = await this.userRepository.update(user.id, { password: hash })
      return "Password has changed"
    }
  }

  async verificetion(email: string) {
    const user = await this.userRepository.findOneBy({ email })
    if (!user) {
      throw new UnauthorizedException("user not found")
    } else {
      const up = await this.userRepository.update(user.id, { verif: true })
      this.transporter.sendMail({
        from: 'vardanmargaryan56@gmail.com',
        to: email,
        subject: "Confirmation Email ✔",
        text: "You have successfully passed the verification ",

      },
      )
      return "You have successfully passed the verification"
    }
  }

  async changePassword(id: number, updateUserDto: UpdateUserDto) {
    const { password, password_confirmation, ...body } = updateUserDto
    if (password === password_confirmation) {
      const hash = await bcrypt.hash(password, 10)
      return await this.userRepository.update(id, { password: hash });
    } else {
      throw new UnauthorizedException("password and password confirmation must be the same")
    }
  }

  remove(id: number) {
    if(id==0){
      throw new UnauthorizedException("User not found")
    }
    return this.userRepository.delete(id);
  }
}
