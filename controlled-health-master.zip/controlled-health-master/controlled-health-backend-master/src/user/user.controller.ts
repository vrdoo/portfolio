import { Controller, Get, Post, Body, Patch, Param, Delete, Res, HttpStatus } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { Response } from 'express';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) { }

  @Post()
  create(@Body() createUserDto: CreateUserDto, @Res() res: Response) {
    try {
      const data = this.userService.create(createUserDto);
      return res.status(HttpStatus.OK).json(data)
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ error: e.message })
    }
  }

  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Get(':email')
  async findOne(@Param('email') email: string, @Res() res: Response) {
    try {
      const data = await this.userService.findOne(email)
      return res.status(HttpStatus.OK).json(data)

    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ message: e.message })
    }
  }
  
  @Get('get/:id')
  async findOneByID(@Param('id') id: number, @Res() res: Response) {
    try {
      const data = await this.userService.findOneById(id)
      return res.status(HttpStatus.OK).json(data)

    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ message: e.message })
    }
  }


  @Patch(':id')
  update(@Param('id') id: string, @Body() updateUserDto: UpdateUserDto) {
    return this.userService.update(+id, updateUserDto);
  }


  @Post('password')
  async emailverif(@Body() updateUserDto: UpdateUserDto, @Res() res: Response) {
    try {
      const user = await this.userService.emailverif(updateUserDto.email)
      return res.status(HttpStatus.OK).json(user)
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ error: e.message })
    }
  }

  @Post('confirmation')
  async verificetion(@Body() updateUserDto: UpdateUserDto, @Res() res: Response) {
    try {
      const user = await this.userService.verificetion(updateUserDto.email)
      return res.status(HttpStatus.OK).json(user)
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ error: e.message })
    }
  }


  @Patch('reset/:id')
  async changePassword(@Body() updateUserDto: UpdateUserDto, @Res() res: Response,@Param('id') id: number) {
    try {
      const user = await this.userService.changePassword(id,updateUserDto)
      return res.status(HttpStatus.OK).json(user)
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({ error: e.message })
    }
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.userService.remove(+id);
  }
}