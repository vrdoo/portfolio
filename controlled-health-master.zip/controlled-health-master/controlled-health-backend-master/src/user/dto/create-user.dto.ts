export class CreateUserDto {
    password
    password_confirmation
    email
}
