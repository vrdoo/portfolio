/*
Navicat MySQL Data Transfer

Source Server         : db
Source Server Version : 100428
Source Host           : localhost:3306
Source Database       : health

Target Server Type    : MYSQL
Target Server Version : 100428
File Encoding         : 65001

Date: 2023-06-18 19:51:38
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for acount
-- ----------------------------
DROP TABLE IF EXISTS `acount`;
CREATE TABLE `acount` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of acount
-- ----------------------------
INSERT INTO `acount` VALUES ('2', 'Anna Anyan');

-- ----------------------------
-- Table structure for dashboard
-- ----------------------------
DROP TABLE IF EXISTS `dashboard`;
CREATE TABLE `dashboard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `heightsId` int(11) NOT NULL,
  `weightsId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ae0e41d4b95013e3a171e947438` (`heightsId`),
  KEY `FK_361a70e1ce62a10c744af5b03af` (`weightsId`),
  CONSTRAINT `FK_361a70e1ce62a10c744af5b03af` FOREIGN KEY (`weightsId`) REFERENCES `weight` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ae0e41d4b95013e3a171e947438` FOREIGN KEY (`heightsId`) REFERENCES `height` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of dashboard
-- ----------------------------

-- ----------------------------
-- Table structure for exam
-- ----------------------------
DROP TABLE IF EXISTS `exam`;
CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ancestry` varchar(255) DEFAULT NULL,
  `unitId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_d2370d3d533dff7482e82d137b4` (`unitId`),
  CONSTRAINT `FK_d2370d3d533dff7482e82d137b4` FOREIGN KEY (`unitId`) REFERENCES `unit` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of exam
-- ----------------------------
INSERT INTO `exam` VALUES ('1', 'Fizic', '%', '2');
INSERT INTO `exam` VALUES ('4', 'hjkhnjm', null, '1');

-- ----------------------------
-- Table structure for height
-- ----------------------------
DROP TABLE IF EXISTS `height`;
CREATE TABLE `height` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of height
-- ----------------------------
INSERT INTO `height` VALUES ('2', '85', '2023-06-01');
INSERT INTO `height` VALUES ('4', '52', '2023-06-01');

-- ----------------------------
-- Table structure for range
-- ----------------------------
DROP TABLE IF EXISTS `range`;
CREATE TABLE `range` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of range
-- ----------------------------
INSERT INTO `range` VALUES ('1', '4', '10');
INSERT INTO `range` VALUES ('2', '3', '10');
INSERT INTO `range` VALUES ('3', '8', '20');
INSERT INTO `range` VALUES ('4', '20', '80');
INSERT INTO `range` VALUES ('5', '25', '100');

-- ----------------------------
-- Table structure for reference
-- ----------------------------
DROP TABLE IF EXISTS `reference`;
CREATE TABLE `reference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of reference
-- ----------------------------
INSERT INTO `reference` VALUES ('1', 'LHbhn');
INSERT INTO `reference` VALUES ('2', 'dh');

-- ----------------------------
-- Table structure for result
-- ----------------------------
DROP TABLE IF EXISTS `result`;
CREATE TABLE `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) DEFAULT NULL,
  `examId` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_15d91965444a69aea2b8017a488` (`examId`),
  CONSTRAINT `FK_15d91965444a69aea2b8017a488` FOREIGN KEY (`examId`) REFERENCES `exam` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of result
-- ----------------------------
INSERT INTO `result` VALUES ('14', '0', '1', 'jkhgbv');
INSERT INTO `result` VALUES ('16', '35', '1', 'fgvbhnm');
INSERT INTO `result` VALUES ('17', '87', '4', null);

-- ----------------------------
-- Table structure for unit
-- ----------------------------
DROP TABLE IF EXISTS `unit`;
CREATE TABLE `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of unit
-- ----------------------------
INSERT INTO `unit` VALUES ('1', 'First');
INSERT INTO `unit` VALUES ('2', 'fvgbhj');
INSERT INTO `unit` VALUES ('5', 'gbh');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `admin` tinyint(4) NOT NULL DEFAULT 0,
  `verif` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'margaranvardan8@gmail.com', '$2b$10$eY8KuUh2I9iDu4lvPF9PgOVGnngy/Cu6DDx5RD6toHQq74kjti1Ty', 'VARDAN MARGARYAN', 'M', '2006-04-19', '1', '1');
INSERT INTO `user` VALUES ('2', 'has@gmail.com', '$2b$10$/nvRiSvJ1MjPV7G5SmTXtuRMJ3WmgFrSx4vKxcbqzZcfyo5u0gPuS', null, null, null, '0', '1');

-- ----------------------------
-- Table structure for weight
-- ----------------------------
DROP TABLE IF EXISTS `weight`;
CREATE TABLE `weight` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `rangeId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_9e9d88ed840ec4651399b4cdd0a` (`rangeId`),
  CONSTRAINT `FK_9e9d88ed840ec4651399b4cdd0a` FOREIGN KEY (`rangeId`) REFERENCES `range` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- ----------------------------
-- Records of weight
-- ----------------------------
INSERT INTO `weight` VALUES ('1', '2', '2017-08-11 21:36', '3');
INSERT INTO `weight` VALUES ('4', '95', '2023-06-01 10:46', '2');
SET FOREIGN_KEY_CHECKS=1;
