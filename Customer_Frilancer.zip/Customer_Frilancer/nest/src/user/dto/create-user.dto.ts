export class CreateUserDto {
    username
    password
    profesion
    role
}
