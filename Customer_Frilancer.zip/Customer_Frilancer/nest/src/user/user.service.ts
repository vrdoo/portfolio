import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { User } from './entities/user.entity';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt'
import { Role } from 'src/model/role.enum';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
  ) { }


  async create(createUserDto: CreateUserDto) {
    const users = await this.userRepository.find()
    if (users.some(e => e.username == createUserDto.username)) {
      throw new UnauthorizedException("that username already had")
    }else if(createUserDto.role==Role.Frilanser && !createUserDto.profesion){
      throw new UnauthorizedException("Frilancer must have profesion")
    }else if(createUserDto.role==Role.Customer && createUserDto.profesion){
      throw new UnauthorizedException("Customer already have profesion")
    }
    const { password, ...body } = createUserDto
    const hash = await bcrypt.hash(password, 10)
    if(!createUserDto.profesion){
      await this.userRepository.save({ ...body, password: hash ,profesion:"Customer"});
      return true
    }
  }

  findAll() {
    return this.userRepository.find();
  }

  async findOne(username: string) {
    const user =  await this.userRepository.findOne({
      where: {
        username
      },
      relations: [
        "works","wish.work","messages.frilanser","comments.user"
      ]
    });
    if(!user){
      throw new UnauthorizedException("user not fount")
    }else{
      return user
    }
  }

async findOneById(id:number){
  return await this.userRepository.findOne({
    where:{
      id
    },
    relations:[
      "comments.user"
    ]
  })
}

  update(id: number, updateUserDto: UpdateUserDto) {
    return `This action updates a #${id} user`;
  }

  remove(id: number) {
    return `This action removes a #${id} user`;
  }
}
