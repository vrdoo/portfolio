import { Comment } from 'src/comment/entities/comment.entity';
import { Likework } from 'src/likework/entities/likework.entity';
import { Message } from 'src/message/entities/message.entity';
import { Role } from 'src/model/role.enum';
import { Work } from 'src/works/entities/work.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class User {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name: string;

    @Column()
    surname: string;


    @Column()
    username: string;

    @Column()
    password: string;

    @Column()
    role:Role

    @Column()
    salary:number

    @Column({nullable:true,default:"Customer"})
    profesion:string


    @OneToMany(type=>Work, work=>work.user)
    works:Work[]

    @OneToMany(type=>Comment, comm=>comm.user)
    comment:Comment[]

    @OneToMany(type=>Comment, comm=>comm.frilanc)
    comments:Comment[]

    @OneToMany(type=>Likework,like=>like.user)
    wish:Likework[]

    @OneToMany(type=>Message,mes=>mes.frilanser)
    message:Message[]

    @OneToMany(type=>Message,mess=>mess.customer)
    messages:Message
}