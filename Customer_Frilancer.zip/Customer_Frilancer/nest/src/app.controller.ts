import { Controller, Get, UseGuards, Post, Request, Body, UploadedFile, UseInterceptors, Res, HttpStatus } from '@nestjs/common';
import { AppService } from './app.service';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from './auth/auth.service';
import { HasRoles } from './auth/has-roles.decorator';
import { Role } from './model/role.enum';
import { RolesGuard } from './auth/roles.guard';
import { LocalAuthGuard } from './auth/local-auth.guard';
import { JwtAuthGuard } from './auth/jwt-auth.guard';
import { ParseFilePipe, MaxFileSizeValidator, FileTypeValidator } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { UserService } from './user/user.service';
import { Response } from 'express';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService,
    private readonly userSerevice: UserService,
    private authService: AuthService) { }

  @UseGuards(LocalAuthGuard)
  @Post('auth/login')
  async login(@Request() req) {
    return this.authService.login(req.user);
  }

  @UseGuards(JwtAuthGuard)
  @Get('profile')
  async getProfile(@Request() req, @Res() res: Response) {
    try {
      const data = await this.userSerevice.findOne(req.user.username)
      return res.status(HttpStatus.OK).json({ user: data })
    } catch (e) {
      return res.status(HttpStatus.BAD_REQUEST).json({
        error: e.message
      })
    }
  }

  @HasRoles(Role.Frilanser)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('frilanser')
  onlyFrilanser(@Request() req) {
    return req.user;
  }

  @HasRoles(Role.Customer)
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Get('customer')
  onlyCustomer(@Request() req) {
    return req.user;
  }

}
