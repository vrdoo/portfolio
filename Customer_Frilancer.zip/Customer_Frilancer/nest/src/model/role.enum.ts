export enum Role{
    Frilanser='Frilanser',
    Customer='Customer'
}