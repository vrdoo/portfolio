import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { TypeOrmModule } from "@nestjs/typeorm"
import { User } from './user/entities/user.entity';
import { WorksModule } from './works/works.module';
import { CommentModule } from './comment/comment.module';
import { LikeworkModule } from './likework/likework.module';
import { UserModule } from './user/user.module';
import { Work } from './works/entities/work.entity';
import { Likework } from './likework/entities/likework.entity';
import { Comment } from './comment/entities/comment.entity';
import { MessageModule } from './message/message.module';
import { Message } from './message/entities/message.entity';


@Module({
  imports: [AuthModule,
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '',
      database: 'frilans_custom',
      entities: [User,Work,Likework,Comment,Message],
      synchronize: true,
    }),
    UserModule,
    WorksModule,
    CommentModule,
    LikeworkModule,
    MessageModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule { }
