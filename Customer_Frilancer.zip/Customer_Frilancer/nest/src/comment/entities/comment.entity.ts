import { Role } from 'src/model/role.enum';
import { User } from 'src/user/entities/user.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Comment {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("int")
    userId: number

    @Column("text")
    text: string

    @Column()
    num: number

    @Column("int")
    frilancId: number

    @ManyToOne(type => User, user => user.comment, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    user: User

    @ManyToOne(type => User, us => us.comments,
        {
            onUpdate: "CASCADE",
            onDelete: "CASCADE"
        })
    frilanc: User
}