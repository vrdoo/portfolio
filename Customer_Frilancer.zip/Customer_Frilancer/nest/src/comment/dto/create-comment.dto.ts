export class CreateCommentDto {
    frilancId
    userId
}
