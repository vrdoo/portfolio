import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateCommentDto } from './dto/create-comment.dto';
import { UpdateCommentDto } from './dto/update-comment.dto';
import { Comment } from './entities/comment.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from 'src/user/entities/user.entity';
import { Role } from 'src/model/role.enum';

@Injectable()
export class CommentService {

  constructor(
    @InjectRepository(Comment) private comRepository: Repository<Comment>,
    @InjectRepository(User) private userRepository: Repository<User>,
  ) { }

  async create(createCommentDto: CreateCommentDto) {
    const customer = await this.userRepository.findOne({
      where: {
        id:createCommentDto.userId
      }
    })
    const frilancer=await this.userRepository.findOne({
      where:{
        id:createCommentDto.frilancId
      }
    })
    if (customer.role == Role.Customer && frilancer.role==Role.Frilanser) {
      await this.comRepository.save(createCommentDto)
      return true
    }
    else if(customer.role==Role.Frilanser) {
      throw new UnauthorizedException("Frilancer can't add comment")
    }else if(frilancer.role==Role.Customer){
      throw new UnauthorizedException("Customer can't resive comment")
    }
  }

  findAll() {
    return this.comRepository.find();
  }

  findOne(id: number) {
    return `This action returns a #${id} comment`;
  }

  update(id: number, updateCommentDto: UpdateCommentDto) {
    return `This action updates a #${id} comment`;
  }

  remove(id: number) {
    return this.comRepository.delete(id);
  }
}
