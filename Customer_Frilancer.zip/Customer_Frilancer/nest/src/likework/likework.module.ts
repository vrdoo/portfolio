import { Module } from '@nestjs/common';
import { LikeworkService } from './likework.service';
import { LikeworkController } from './likework.controller';
import { Likework } from './entities/likework.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { Work } from 'src/works/entities/work.entity';

@Module({
  imports :[TypeOrmModule.forFeature([Likework,User,Work])],
  controllers: [LikeworkController],
  providers: [LikeworkService],
  exports:[LikeworkService]
})
export class LikeworkModule {}
