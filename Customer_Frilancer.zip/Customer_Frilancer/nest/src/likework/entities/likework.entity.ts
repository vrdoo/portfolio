import { User } from "src/user/entities/user.entity";
import { Work } from "src/works/entities/work.entity";
import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";



@Entity()
export class Likework {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("int")
    workId: number

    @Column("int")
    userId: number

    @ManyToOne(type => Work, work => work.wish, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    work: Work


    @ManyToOne(type => User, user => user.wish, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    user: User


}