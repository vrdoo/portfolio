import { Test, TestingModule } from '@nestjs/testing';
import { LikeworkController } from './likework.controller';
import { LikeworkService } from './likework.service';

describe('LikeworkController', () => {
  let controller: LikeworkController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [LikeworkController],
      providers: [LikeworkService],
    }).compile();

    controller = module.get<LikeworkController>(LikeworkController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
