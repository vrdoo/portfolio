import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateLikeworkDto } from './dto/create-likework.dto';
import { UpdateLikeworkDto } from './dto/update-likework.dto';
import { Likework } from './entities/likework.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from 'src/user/entities/user.entity';
import { Role } from 'src/model/role.enum';
import { Work } from 'src/works/entities/work.entity';

@Injectable()
export class LikeworkService {

  constructor(
    @InjectRepository(Likework) private likeRepository: Repository<Likework>,
    @InjectRepository(User) private userRepository: Repository<User>,
    @InjectRepository(Work) private workRepository: Repository<Work>,
  ) { }


  async create(createLikeworkDto: CreateLikeworkDto) {
    const worklist= await this.likeRepository.findOne({
      where:{
        workId:createLikeworkDto.workId
      }
    })    
    const work=await this.workRepository.findOne({
      where:{
        id:createLikeworkDto.workId
      }
    })
    const user = await this.userRepository.findOne({
      where: {
        id: createLikeworkDto.userId
      }
    })
    if (user.role==Role.Customer) {
      throw new UnauthorizedException("Customer can't add work for her")
    }else if(worklist){
      throw new UnauthorizedException("That work already had")
    }else if(!work){
      throw new UnauthorizedException("Work not found")
    }
    else {
      await this.likeRepository.save(createLikeworkDto);
      return true
    }
  }

  findAll() {
    return this.likeRepository.find({
      relations:[
        "work"
      ]
    });
  }

  findOne(id: number) {
    return `This action returns a #${id} likework`;
  }

  update(id: number, updateLikeworkDto: UpdateLikeworkDto) {
    return `This action updates a #${id} likework`;
  }

  remove(id: number) {
    return this.likeRepository.delete(id);
  }
}
