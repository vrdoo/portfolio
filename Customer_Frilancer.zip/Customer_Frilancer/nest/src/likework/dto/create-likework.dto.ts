export class CreateLikeworkDto {
    userId
    workId
}
