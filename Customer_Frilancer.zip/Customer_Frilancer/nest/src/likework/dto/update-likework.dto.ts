import { PartialType } from '@nestjs/mapped-types';
import { CreateLikeworkDto } from './create-likework.dto';

export class UpdateLikeworkDto extends PartialType(CreateLikeworkDto) {}
