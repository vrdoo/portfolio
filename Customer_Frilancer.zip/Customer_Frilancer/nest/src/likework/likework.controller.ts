import { Controller, Get, Post, Body, Patch, Param, Delete, Res, HttpStatus } from '@nestjs/common';
import { LikeworkService } from './likework.service';
import { CreateLikeworkDto } from './dto/create-likework.dto';
import { UpdateLikeworkDto } from './dto/update-likework.dto';
import { Response } from 'express';

@Controller('likework')
export class LikeworkController {
  constructor(private readonly likeworkService: LikeworkService) {}

  @Post()
  create(@Body() createLikeworkDto: CreateLikeworkDto ,@Res() res:Response) {
    try{
      const data =   this.likeworkService.create(createLikeworkDto);
      return res.status(HttpStatus.OK).json(data)
      }catch(e){
        return res.status(HttpStatus.BAD_REQUEST).json({error:e.message})
      }
  }

  @Get()
  findAll() {
    return this.likeworkService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.likeworkService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateLikeworkDto: UpdateLikeworkDto) {
    return this.likeworkService.update(+id, updateLikeworkDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.likeworkService.remove(+id);
  }
}
