import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateMessageDto } from './dto/create-message.dto';
import { UpdateMessageDto } from './dto/update-message.dto';
import { User } from 'src/user/entities/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Message } from './entities/message.entity';
import { Role } from 'src/model/role.enum';

@Injectable()
export class MessageService {

  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
    @InjectRepository(Message) private mesRepository: Repository<Message>,
  ) { }

async  create(createMessageDto: CreateMessageDto) {
  const customer=await this.userRepository.findOne({
    where:{
      id:createMessageDto.customerId
    }
  })
  const frilanser=await this.userRepository.findOne({
    where:{
      id:createMessageDto.frilanserId
    }
  })
  if(customer.role==Role.Customer && frilanser.role==Role.Frilanser){
    await this.mesRepository.save(createMessageDto)
    return "Message send"
  }else if(customer.role==Role.Frilanser){
    throw new UnauthorizedException("Frilanser can't send a message")
  }else if(frilanser.role==Role.Customer){
    throw new UnauthorizedException("Customer can't resive a message")
  }
  }

  findAll() {
    return this.mesRepository.find();
  }

  findOne(id: number) {
    return this.mesRepository.find({
      where:{
        customerId:id
      },
      relations:[
        "frilanser"
      ]
    });
  }

  update(id: number, updateMessageDto: UpdateMessageDto) {
    return `This action updates a #${id} message`;
  }

  remove(id: number) {
    return this.mesRepository.delete(id);
  }
}
