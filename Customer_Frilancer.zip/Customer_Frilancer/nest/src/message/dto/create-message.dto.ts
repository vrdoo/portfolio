export class CreateMessageDto {
    customerId
    frilanserId
}
