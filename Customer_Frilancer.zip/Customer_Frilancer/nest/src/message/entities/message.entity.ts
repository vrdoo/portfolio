import { Comment } from 'src/comment/entities/comment.entity';
import { Likework } from 'src/likework/entities/likework.entity';
import { Role } from 'src/model/role.enum';
import { User } from 'src/user/entities/user.entity';
import { Work } from 'src/works/entities/work.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Message {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("int")
    customerId: number

    @Column("int")
    frilanserId: number

    @ManyToOne(type => User, user => user.message, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    customer: User

    @ManyToOne(type => User, user => user.messages, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    frilanser: User
}