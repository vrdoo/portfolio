import { Module } from '@nestjs/common';
import { WorksService } from './works.service';
import { WorksController } from './works.controller';
import { Work } from './entities/work.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';

@Module({
  imports :[TypeOrmModule.forFeature([Work,User])],
  controllers: [WorksController],
  providers: [WorksService],
  exports:[WorksService]

})
export class WorksModule {}
