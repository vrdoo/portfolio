export class CreateWorkDto {
    userId
}
