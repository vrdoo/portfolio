import { Likework } from 'src/likework/entities/likework.entity';
import { User } from 'src/user/entities/user.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Work {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    title: string

    @Column()
    description: string

    @Column()
    price: number

    @Column("int")
    userId: number

    @Column({ default: false })
    done: boolean

    @ManyToOne(type => User, user =>user.id, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    user: User

    @OneToMany(type => Likework, like => like.work)
    wish: Likework[]
}