import { Injectable, UnauthorizedException } from '@nestjs/common';
import { CreateWorkDto } from './dto/create-work.dto';
import { UpdateWorkDto } from './dto/update-work.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Work } from './entities/work.entity';
import { Repository } from 'typeorm';
import { User } from 'src/user/entities/user.entity';
import { Role } from 'src/model/role.enum';

@Injectable()
export class WorksService {

  constructor(
    @InjectRepository(Work) private workRepository: Repository<Work>,
    @InjectRepository(User) private userRepository: Repository<User>,
  ) { }

  async create(createWorkDto: CreateWorkDto) {
    const user = await this.userRepository.findOne({
      where: {
        id: createWorkDto.userId
      }
    })
    console.log(user);
    if (!user) {
      throw new UnauthorizedException("Customer not found")
    }
    else if (user.role == Role.Customer) {
      await this.workRepository.save(createWorkDto)
      return true
    }
    else {
      throw new UnauthorizedException("Frilancer can't add work")
    }
  }

  async findAll() {
    return await this.workRepository.find();
  }

  async findOne(id: number) {
    return await this.workRepository.findOneBy({ id });
  }

  update(id: number, updateWorkDto: UpdateWorkDto) {
    return `This action updates a #${id} work`;
  }

  async remove(id: number) {
    return await this.workRepository.delete(id);
  }
}
