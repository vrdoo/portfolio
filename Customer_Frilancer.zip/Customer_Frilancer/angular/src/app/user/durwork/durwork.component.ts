import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { CookieService } from "ngx-cookie-service"
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserGet, Work } from '../type';
import { Store } from '@ngrx/store';
import { App } from 'src/app/app.type';
import { getUser, getWorks } from '../store/selector';
import { delWishStart, getUserStart, getWorkStart, messageStart } from '../store/action';


@Component({
  selector: 'app-durwork',
  templateUrl: './durwork.component.html',
  styleUrls: ['./durwork.component.css']
})
export class DurworkComponent {



  user!: UserGet

  constructor(private cookis: CookieService, private http: HttpClient, private router: Router, private store: Store) {
    store.select(getUser).subscribe((data: any) => {
      this.user = data
      console.log(data);
    })
  }

  ngOnInit(): void {
    this.store.dispatch(getUserStart())
    const token = this.cookis.get("token")
    if (!token) {
      this.router.navigate(["/"])
    }
  }


  navigate() {
    this.router.navigate(["profile"])
  }

  workOff(id: number, wId: number) {
    this.store.dispatch(messageStart({ fId: this.user.id, cId: id }))
    this.store.dispatch(delWishStart({ id: wId }))
    this.store.dispatch(getUserStart())
  }
}
