import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DurworkComponent } from './durwork.component';

describe('DurworkComponent', () => {
  let component: DurworkComponent;
  let fixture: ComponentFixture<DurworkComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DurworkComponent]
    });
    fixture = TestBed.createComponent(DurworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
