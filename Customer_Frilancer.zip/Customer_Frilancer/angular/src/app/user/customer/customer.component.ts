import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { CookieService } from "ngx-cookie-service"
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserGet, Work } from '../type';
import { Store } from '@ngrx/store';
import { App } from 'src/app/app.type';
import { getError, getUser, getWorks } from '../store/selector';
import { addWishStart, getUserStart, getWorkStart, logOutSuccess, wisherror } from '../store/action';
import { UserService } from '../user.service';



@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {


  user!: UserGet
  works!: Work[]
  bool: boolean = true
  errorMsg!: string
  wind!:boolean

  constructor(private cookis: CookieService, private http: HttpClient, private router: Router, private store: Store) {
    store.select(getUser).subscribe((data: any) => {
      this.user = data
    })
    store.select(getError).subscribe(data => {
      this.errorMsg = data
    })
  }

  ngOnInit(): void {
    this.wind = UserService.bool
    this.store.dispatch(getUserStart())
    const token = this.cookis.get("token")
    if (!token || this.user.role == "Frilancer") {
      this.router.navigate(["/"])
    }
    if (this.works?.some((e, i) => e.id == this.user.wish[i]?.workId)) [
      this.bool = false
    ]
  }

  logOut() {
    this.cookis.delete("token")
    this.store.dispatch(logOutSuccess())
    const token = this.cookis.get("token")
    console.log(token);
    if (!token) {
      this.router.navigate(["/"])
    }
  }

  navigate() {
    this.router.navigate(["hire_frilancer"])
  }

  change() {
    this.wind = !this.wind
    UserService.bool = !UserService.bool
    console.log(UserService.bool);
  }
}
