import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppRoutingModule } from "../app-routing.module";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule ,FormsModule} from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { CustomerComponent } from "./customer/customer.component";
import { DurworkComponent } from "./durwork/durwork.component";
import { FrilanseerComponent } from "./frilanseer/frilanseer.component";
import { UserOwnComponent } from "./user-own/user-own.component";
import { UsersComponent } from "./users/users.component";
import { UserService } from "./user.service";
import {CookieService} from "ngx-cookie-service";
import { WindoComponent } from './windo/windo.component'
import { UserEffects } from "./store/effects";
import { EffectsModule } from "@ngrx/effects";
import { userReducer } from "./store/reducer";
import { StoreModule } from "@ngrx/store";
import {MatIconModule} from "@angular/material/icon";
import { ModalComponent } from './modal/modal.component'



@NgModule({
    declarations: [
        CustomerComponent,
        DurworkComponent,
        FrilanseerComponent,
        UserOwnComponent,
        UsersComponent,
        WindoComponent,
        ModalComponent
    ],
    imports: [
      BrowserModule,
      AppRoutingModule,
      CommonModule,
      ReactiveFormsModule,
      FormsModule,
      HttpClientModule,
      StoreModule.forFeature("users", userReducer),
      EffectsModule.forFeature([UserEffects]),
      MatIconModule
    ],
    providers: [UserService,CookieService],
    bootstrap: [
        CustomerComponent,
        DurworkComponent,
        FrilanseerComponent,
        UserOwnComponent,
        UsersComponent,
        WindoComponent,
        ModalComponent
    ],
    exports:[
        CustomerComponent,
        DurworkComponent,
        FrilanseerComponent,
        UserOwnComponent,
        UsersComponent,
        WindoComponent,
        ModalComponent
    ]
  })
  export class UserModule { }