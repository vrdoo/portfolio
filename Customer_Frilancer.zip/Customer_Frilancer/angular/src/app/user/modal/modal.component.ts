import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getUserIdStart } from '../store/action';
import { UserGet } from '../type';
import { getUserById } from '../store/selector';
import { UserOwnComponent } from '../user-own/user-own.component';
import { UserService } from '../user.service';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  @Input() id!:number
  @Input() bool!:boolean
  user!:UserGet
  userId!:number


  constructor(private store:Store, private cust :UserOwnComponent){
    store.select(getUserById).subscribe((data:any)=>{
      this.user=data
    })    
  }


  ngOnInit(): void {
    this.store.dispatch(getUserIdStart({id:this.id}))
  }

    cansle() {
    this.bool = !this.bool
    UserService.modal = !UserService.modal
    this.cust.ngOnInit()
  }
}
