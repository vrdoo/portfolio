import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { CookieService } from "ngx-cookie-service"
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserGet } from '../type';
import { Store } from '@ngrx/store';
import { App } from 'src/app/app.type';
import { getUser } from '../store/selector';
import { getUserStart } from '../store/action';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent {

  user!: UserGet


  constructor(private cookis: CookieService, private http: HttpClient, private router: Router,private store:Store) {
    store.select(getUser).subscribe((data: any) => {
      this.user=data
    })
  }

  ngOnInit(): void {
    this.store.dispatch(getUserStart())
    const token = this.cookis.get("token")
    if (!token) {
      this.router.navigate(["/"])
    }
  }
}