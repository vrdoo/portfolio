import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { CookieService } from "ngx-cookie-service"
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserGet, Work } from '../type';
import { Store } from '@ngrx/store';
import { App } from 'src/app/app.type';
import { getError, getUser, getWorks } from '../store/selector';
import { addWishStart, getUserStart, getWorkStart, logOutSuccess, wisherror } from '../store/action';


@Component({
  selector: 'app-frilanseer',
  templateUrl: './frilanseer.component.html',
  styleUrls: ['./frilanseer.component.css']
})
export class FrilanseerComponent {


  user!: UserGet
  works!:Work[]
  bool:boolean=true
  errorMsg!:string
  
  constructor(private cookis: CookieService, private http: HttpClient, private router: Router, private store: Store) {
    store.select(getUser).subscribe((data: any) => {
      this.user = data
    })
    store.select(getWorks).subscribe(data=>{
      this.works=data
      this.works = this.works.map(e=>this.user.wish?.some(elm=> elm && elm.workId==e.id)?({...e, bool:false}):({...e, bool:true}))
    })
    store.select(getError).subscribe(data=>{
      this.errorMsg=data
    })    
  }
  
  ngOnInit(): void {
    this.store.dispatch(getUserStart())
    this.store.dispatch(getWorkStart())
    const token = this.cookis.get("token")
    if (!token || this.user.role=="Customer") {
      this.router.navigate(["/"])
    }
    
    
  }
  
  logOut() {
    this.cookis.delete("token")
    this.store.dispatch(logOutSuccess())
    const token = this.cookis.get("token")
    console.log(token);
    if (!token) {
      this.router.navigate(["/"])
    }
  }
  
  navigate(){
    this.router.navigate(["my_during_work"])
  }
  check(){
    if(this.errorMsg){
      console.log("====>");
      alert("Work already had in your during work lists")
    }
  }
  
  addWork(workId:number){
    this.store.dispatch(addWishStart({work:{workId:workId,userId:this.user.id}}))
    this.check()
  }
  
}
