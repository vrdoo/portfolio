import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FrilanseerComponent } from './frilanseer.component';

describe('FrilanseerComponent', () => {
  let component: FrilanseerComponent;
  let fixture: ComponentFixture<FrilanseerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FrilanseerComponent]
    });
    fixture = TestBed.createComponent(FrilanseerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
