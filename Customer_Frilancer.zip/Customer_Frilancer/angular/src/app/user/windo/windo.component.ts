import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getError, getMessage } from '../store/selector';
import { Messages } from '../type';
import { addCommentStart, deleteCommentStart, getMessageStart } from '../store/action';
import { UserService } from '../user.service';
import { CustomerComponent } from '../customer/customer.component';

@Component({
  selector: 'app-windo',
  templateUrl: './windo.component.html',
  styleUrls: ['./windo.component.css']
})
export class WindoComponent implements OnInit {

  @Input() id!: number
  @Input() bool!: boolean
  message!: Messages[]
  errorMessage!:string

  stars: number[] = [1, 2, 3, 4, 5];
  selectedValue: number = 0;
  isMouseover = true;



  constructor(private store: Store,private cust:CustomerComponent) {
    store.select(getMessage).subscribe((data: any) => {
      this.message = data
    })
    store.select(getError).subscribe((data:any)=>{
      this.errorMessage=data
    })
  }


  ngOnInit(): void {
    this.store.dispatch(getMessageStart({ id: this.id }))

  }

  cansle() {
    this.bool = !this.bool
    UserService.bool = !UserService.bool
    this.cust.ngOnInit()
  }

  countStar(star: number) {
    this.isMouseover = false;
    this.selectedValue = star;
  }

  addClass(star: number) {
    if (this.isMouseover) {
      this.selectedValue = star;
    }
  }

  removeClass() {
    if (this.isMouseover) {
      this.selectedValue = 0;
    }
  }

  sendMessage({id,text,comId}:{id:number,text:string,comId:number}){
    if(this.errorMessage){
      alert(this.errorMessage)
    }
    this.store.dispatch(addCommentStart({com:{userId:this.id,frilancId:id,text,num:this.selectedValue}}))
    this.store.dispatch(deleteCommentStart({id:comId}))
    this.store.dispatch(getMessageStart({id:this.id}))
  }
}
