import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WindoComponent } from './windo.component';

describe('WindoComponent', () => {
  let component: WindoComponent;
  let fixture: ComponentFixture<WindoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WindoComponent]
    });
    fixture = TestBed.createComponent(WindoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
