import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { CookieService } from "ngx-cookie-service";
import { Observable, delay, of } from "rxjs";


@Injectable()
export class UserService {
    constructor(private http: HttpClient,private cookis: CookieService) { }

    static bool:boolean=false
    static modal:boolean=false

    getUser(token:string) {
       return this.http.get("http://localhost:8080/profile", { headers: { "Authorization": `Bearer ${token}` } })
    }

    getUserById(id:number){
        return this.http.get(`http://localhost:8080/user/user/${id}`)
    }

    getWorks(){
        return this.http.get("http://localhost:8080/works")
    }


    addWish(obj:any){
        return this.http.post("http://localhost:8080/likework",obj)
    }

    deleteWish(id:number){
        return this.http.delete(`http://localhost:8080/likework/${id}`)
    }

    sendmessage(fId:number,cId:number){
        return this.http.post("http://localhost:8080/message",{frilanserId:fId,customerId:cId})
    }

    logOut(){
      return  this.cookis.delete("token")
    }

    getMessage(id:number){
        return this.http.get(`http://localhost:8080/message/${id}`)
    }

    addComment(obj:any){
        console.log(obj);
        return this.http.post("http://localhost:8080/comment",obj)
    }

    deleteComment(id:number){
        return this.http.delete(`http://localhost:8080/comment/${id}`)
    }

    deleteMessage(id:number){
        return this.http.delete(`http://localhost:8080/message/${id}`)
    }

    getAllUser(){
        return this.http.get("http://localhost:8080/user")
    }
}