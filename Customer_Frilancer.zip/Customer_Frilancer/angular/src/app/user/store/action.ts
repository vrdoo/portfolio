import { createAction, props } from "@ngrx/store"
import { Comments, Messages, UserGet, Work } from "../type"

export const getUserStart=createAction("getuserstart")
export const getUserSuccess = createAction("getUserSuccess",props<{user:UserGet}>())
export const usererror=createAction("usererror",props<{errorMsg:string}>())


export const getWorkStart=createAction("getWorkStart")
export const getWorkSuccess = createAction("getWorkSuccess",props<{works:Work[]}>())
export const workerror=createAction("usererror",props<{errorMsg:string}>())

export const getAllUserStart=createAction("getAllUserStart")
export const getAllUserSuccess = createAction("getAllUserSuccess",props<{users:UserGet[]}>())
export const userAllerror=createAction("userAllerror",props<{errorMsg:string}>())

export const getUserIdStart=createAction("getUserIdStart",props<{id:number}>())
export const getUserIdSuccess = createAction("getUserIdSuccess",props<{user:UserGet}>())
export const userIderror=createAction("userIderror",props<{errorMsg:string}>())


export const addWishStart=createAction("addWishStart",props<{work:any}>())
export const addWishSuccess=createAction("addWishSuccess")
export const wisherror=createAction("wisherror",props<{errorMsg:string}>())


export const delWishStart=createAction("delWishStart",props<{id:number}>())
export const delWishSuccess=createAction("delWishSuccess")
export const delwisherror=createAction("delwisherror",props<{errorMsg:string}>())

export const messageStart=createAction("messageStart",props<{fId:number,cId:number}>())
export const messageSuccess=createAction("messageSuccess")
export const messageerror=createAction("messageerror",props<{errorMsg:string}>())


export const  logOutStart=createAction("logout")
export const  logOutSuccess=createAction("logOutSuccess")
export const  logOutError=createAction("logOutError",props<{errorMsg:string}>())


export const getMessageStart=createAction("getmessage",props<{id:number}>())
export const getMessageSuccess=createAction("getmessage",props<{message:Messages[]}>())
export const errorMessage=createAction("getmessage",props<{errorMsg:string}>())


export const addCommentStart=createAction("addCommentStart",props<{com:Comments}>())
export const addCommentSuccess=createAction("addCommentSuccess")
export const errorComment=createAction("errorComment",props<{errorMsg:string}>())

export const deleteCommentStart=createAction("deleteCommentStart",props<{id:number}>())
export const deleteCommentSuccess=createAction("deleteCommentSuccess")
export const errorDeleteComment=createAction("errorDeleteComment",props<{errorMsg:string}>())