import { createFeatureSelector, createSelector } from "@ngrx/store";
import { UserState } from "./reducer";


const getUserState = createFeatureSelector<UserState>("users")



export const getUser = createSelector(getUserState, (state) => {
   return state.user
})

export const getWorks = createSelector(getUserState, (state) => {
   return state.works
})


export const getError = createSelector(getUserState, (state) => {
   return state.errorMessage
})

export const getMessage = createSelector(getUserState, (state) => {
   return state.messages
})


export const getAllUser=createSelector(getUserState,(state)=>{
   return state.users
})


export const getUserById=createSelector(getUserState,(state)=>{
   return state.hiUer
})