import { Injectable } from "@angular/core";
import { mergeMap, map, of, catchError, Observable, EMPTY, exhaustMap } from "rxjs"
import { ActivatedRoute, Router } from "@angular/router";
import { createEffect, ofType, Actions } from "@ngrx/effects"
import { CookieService } from "ngx-cookie-service";
import { UserService } from "../user.service";
import * as UserActions from "./action"



@Injectable()
export class UserEffects {
    constructor(private actions$: Actions, private service: UserService, private router: Router, private cookis: CookieService) { }

    getUser$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.getUserStart),
            exhaustMap((action) => {
                const token = this.cookis.get("token")
                return this.service.getUser(token).pipe(
                    map((data: any) => {
                        return UserActions.getUserSuccess({ user: data.user })
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.usererror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    getWork$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.getWorkStart),
            exhaustMap((action) => {
                return this.service.getWorks().pipe(
                    map((data: any) => {
                        return UserActions.getWorkSuccess({ works: data })
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.workerror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    addWish$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.addWishStart),
            exhaustMap((action) => {
                return this.service.addWish(action.work).pipe(
                    map((data: any) => {
                        return UserActions.addWishSuccess()
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.wisherror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    delWish$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.delWishStart),
            exhaustMap((action) => {
                return this.service.deleteWish(action.id).pipe(
                    map((data: any) => {
                        return UserActions.delWishSuccess()
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.delwisherror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })

    addMessage$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.messageStart),
            exhaustMap((action) => {
                return this.service.sendmessage(action.fId, action.cId).pipe(
                    map((data: any) => {
                        return UserActions.messageSuccess()
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.messageerror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    getMessage$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.getMessageStart),
            exhaustMap((action) => {
                return this.service.getMessage(action.id).pipe(
                    map((data: any) => {
                        return UserActions.getMessageSuccess({message:data})
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.errorMessage({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    addComment$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.addCommentStart),
            exhaustMap((action) => {
                return this.service.addComment(action.com).pipe(
                    map((data: any) => {
                        return UserActions.addCommentSuccess()
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.errorComment({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    deleteComment$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.deleteCommentStart),
            exhaustMap((action) => {
                return this.service.deleteMessage(action.id).pipe(
                    map((data: any) => {
                        return UserActions.deleteCommentSuccess()
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.errorDeleteComment({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    getAllUser$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.getAllUserStart),
            exhaustMap((action) => {
                return this.service.getAllUser().pipe(
                    map((data: any) => {
                        return UserActions.getAllUserSuccess({users:data})
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.userAllerror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
    getUserById$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(UserActions.getUserIdStart),
            exhaustMap((action) => {
                return this.service.getUserById(action.id).pipe(
                    map((data: any) => {
                        return UserActions.getUserIdSuccess({user:data})
                    }),
                    catchError((error: { message: string }) =>
                        of(UserActions.userIderror({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
}