import { createReducer, on } from "@ngrx/store"
import * as UserActions from "./action"
import * as LogActions from "../../logIn/store/log.action"
import { Comments, Messages, UserGet, Wish, Work } from "../type"

export interface UserState {
    users: UserGet[]
    messages: Messages[]
    comments: Comments
    user: UserGet
    wish: Wish[]
    works: Work[]
    errorMessage: string
    hiUer:UserGet
}

export const initialState: UserState = {
    users: [],
    messages: [],
    comments: {} as Comments,
    user: {} as UserGet,
    wish: [],
    works: [],
    errorMessage: "",
    hiUer:{} as UserGet
}



const _userReducer = createReducer(
    initialState,
    on(UserActions.getUserSuccess, (state, action) => ({
        ...state,
        user: action.user
    })),
    on(UserActions.getWorkSuccess, (state, action) => ({
        ...state,
        works: action.works
    })),
    on(UserActions.getWorkSuccess, (state, action) => ({
        ...state,
        user: state.user
    })),
    on(UserActions.wisherror, (state, action) => ({
        ...state,
        errorMessage: action.errorMsg
    })),
    on(UserActions.delwisherror, (state, action) => ({
        ...state,
        errorMessage: action.errorMsg
    })),
    on(UserActions.delWishSuccess, (state, action) => ({
        ...state,
        user: state.user
    })),
    on(UserActions.messageerror, (state, action) => ({
        ...state,
        errorMessage: action.errorMsg
    })),
    on(UserActions.messageSuccess, (state, action) => ({
        ...state,
        user: state.user
    })),
    on(UserActions.logOutSuccess, (state, action) => ({
        ...state,
        user: {} as UserGet
    })),
    on(LogActions.getLogInSuccess, (state, action) => ({
        ...state,
        user: action.user
    })),
    on(UserActions.getMessageSuccess, (state, action) => ({
        ...state,
        messages: action.message
    })),
    on(UserActions.errorComment, (state, action) => ({
        ...state,
        errorMessage: action.errorMsg
    })),
    on(UserActions.addCommentSuccess, (state, action) => ({
        ...state,
        user: state.user
    })),
    on(UserActions.deleteCommentSuccess, (state, action) => ({
        ...state,
        user: state.user
    })),
    on(UserActions.getAllUserSuccess, (state, action) => ({
        ...state,
        users:action.users
    })),
    on(UserActions.getUserIdSuccess, (state, action) => ({
        ...state,
        hiUer:action.user
    })),
    on(UserActions.userAllerror, (state, action) => ({
        ...state,
        user: state.user
    })),
)



export function userReducer(state: any, action: any) {
    return _userReducer(state, action)
}