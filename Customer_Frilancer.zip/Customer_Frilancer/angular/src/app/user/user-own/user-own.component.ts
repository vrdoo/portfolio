import { Component, OnInit } from '@angular/core';
import { UserGet } from '../type';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { getAllUserStart, getUserStart } from '../store/action';
import { getAllUser, getUser } from '../store/selector';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-own',
  templateUrl: './user-own.component.html',
  styleUrls: ['./user-own.component.css']
})
export class UserOwnComponent implements OnInit {

  users!: UserGet[]
  user!: UserGet
  modal!: boolean
  sub: number = 10
  arrUser!:UserGet[]
  userId!:number

  constructor(private cookis: CookieService, private router: Router, private store: Store) {
    store.select(getUser).subscribe((data: any) => {
      this.user = data      
    })
    store.select(getAllUser).subscribe((data: any) => {
      this.users = data.filter((e: UserGet) => e.role == "Frilanser")
      this.arrUser = this.users.slice(0, this.sub)
    })

  }


  ngOnInit(): void {
    console.log(this.users);
    this.modal = UserService.modal
    this.store.dispatch(getUserStart())
    this.store.dispatch(getAllUserStart())
    const token = this.cookis.get("token")
    if (!token || this.user.role == "Frilancer") {
      this.router.navigate(["/"])
    }
  }

  navigate() {
    this.router.navigate(["profile"])
  }

  change(id:number) {
    this.modal = !UserService.modal
    UserService.modal = !UserService.modal
    this.userId=id
  }

  addSub() {
    this.sub = this.sub + 10
    this.arrUser = this.users.slice(0, this.sub)
  }

  filter({min,max,work}:{min:string,max:string,work:string}){    
      this.arrUser=this.users.filter(e=>e.salary>=+min && e.salary<=+max && e.profesion==work)
  }

}
