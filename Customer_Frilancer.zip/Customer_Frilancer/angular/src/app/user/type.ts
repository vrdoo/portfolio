export interface Work{
    id:number
    done:boolean
    title:string
    userId:number
    description:string
    price:number
    bool:boolean
}

export interface Comments{
    id?:number
    num:number
    userId:number
    frilancId:number
    text:string
    user?:UserGet
}

export interface Messages{
    id:number
    customerId:number
    frilanserId:number
    frilanser:UserGet
}

export interface Wish{
    id:number
    userId:number
    workId:number
    work:Work
}

export interface UserGet{
    id:number,
    name:string,
    surname:string
    username:string
    password:string
    role:string
    salary:number    
    profesion:string
    comments:Comments[]
    messages:Messages[]
    works:Work[]
    wish:Wish[]
}