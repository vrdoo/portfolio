import { UserLogIn } from "./logIn/type";
import { UserGet } from "./user/type";

export interface App{
    log:UserLogIn,
    user:UserGet
}