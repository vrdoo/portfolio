import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './logIn/login/login.component';
import { RegisterComponent } from './logIn/register/register.component';
import { UsersComponent } from './user/users/users.component';
import { UserOwnComponent } from './user/user-own/user-own.component';
import { DurworkComponent } from './user/durwork/durwork.component';

const routes: Routes = [
  {path:"",component:LoginComponent},
  {path:"register",component:RegisterComponent},
  {path:"profile",component:UsersComponent},
  {path:"hire_frilancer",component:UserOwnComponent},
  {path:"my_during_work",component:DurworkComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
