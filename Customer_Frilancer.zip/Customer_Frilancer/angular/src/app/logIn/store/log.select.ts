import { createFeatureSelector, createSelector } from "@ngrx/store";
import { LogState } from "./log.reducer";


const getLogState=createFeatureSelector<LogState>("logs")


export const getTooken = createSelector(getLogState, (state) => {
    return state.tooken
 })

export const getError = createSelector(getLogState, (state) => {
    return state.errorMessage
 })
 
export const getBool = createSelector(getLogState, (state) => {
    return state.bool
 })