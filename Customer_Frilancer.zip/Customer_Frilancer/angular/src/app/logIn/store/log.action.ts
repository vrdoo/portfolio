import { createAction, props } from "@ngrx/store"
import { UserAdd, UserLogIn } from "../type"



export const getLogInStart=createAction("getLogIn",props<{obj:UserLogIn}>())
export const getLogInSuccess = createAction("getLogInSuccess",props<{user:any}>())
export const logInError=createAction("loginerror",props<{errorMsg:string}>())


export const registerStart=createAction("registerstart",props<{user:UserAdd}>())
export const registerSuccess=createAction("registerstart",props<{bool:boolean}>())
export const registerError=createAction("registerstart",props<{errorMsg:string}>())
