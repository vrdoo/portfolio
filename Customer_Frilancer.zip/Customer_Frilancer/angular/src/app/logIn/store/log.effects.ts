import { Injectable } from "@angular/core";
import { mergeMap, map, of, catchError, Observable, EMPTY, exhaustMap } from "rxjs"
import { ActivatedRoute, Router } from "@angular/router";
import { LogInService } from "../logred.servise";
import * as LogActions from "./log.action"
import { createEffect, ofType, Actions } from "@ngrx/effects"
import { CookieService } from "ngx-cookie-service";
import { UserService } from "src/app/user/user.service";


@Injectable()
export class LogEffects {
    constructor(private actions$: Actions, private service: LogInService, private userService:UserService, private router: Router, private cookis: CookieService) { }

    LogIn$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(LogActions.getLogInStart),
            exhaustMap((action) => {
                return this.service.logIn(action.obj).pipe(
                    map((data: any) => {
                        const t=this.cookis.get("token")
                        console.log(t);
                        if(t){
                            this.cookis.delete("token")
                        }
                        this.cookis.set("token", data.access_token.toString())
                        this.router.navigate(["profile"])
                        return LogActions.getLogInSuccess({ user: data.user })
                    }),
                    catchError((error: { message: string }) =>
                        of(LogActions.logInError({ errorMsg: "Username or password invalid" }))
                    )
                )
            })
        )
    })
    Register$ = createEffect(() => {
        return this.actions$.pipe(
            ofType(LogActions.registerStart),
            exhaustMap((action) => {
                return this.service.register(action.user).pipe(
                    map((bool: any) => {
                        this.router.navigate(["/"])
                        return LogActions.registerSuccess({ bool: bool })
                    }),
                    catchError((error: { message: string }) => 
                        of(LogActions.registerError({ errorMsg: error.message }))
                    )
                )
            })
        )
    })
}