import { createReducer, on } from "@ngrx/store"
import * as LogActions from "./log.action"

export interface LogState{
    errorMessage:string,
    tooken:string
    bool:boolean
}

export const initialState: LogState = {
    errorMessage:"",
    tooken:"",
    bool:false
}



const _logReducer = createReducer(
    initialState,
    on(LogActions.getLogInSuccess,(state,action)=>({
        ...state,
    })),
    on(LogActions.logInError,(state,action)=>({
        ...state,
        errorMessage:action.errorMsg
    })),
    on(LogActions.registerSuccess,(state,action)=>({
        ...state,
        bool:action.bool
    })),
    on(LogActions.registerError,(state,action)=>({
        ...state,
        errorMessage:action.errorMsg
    }))
)



export function logReducer(state:any,action:any){
    return _logReducer(state,action)
}