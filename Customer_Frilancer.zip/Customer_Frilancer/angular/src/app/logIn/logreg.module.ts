import { NgModule } from "@angular/core";
import { LoginComponent } from "./login/login.component";
import { RegisterComponent } from "./register/register.component";
import { BrowserModule } from "@angular/platform-browser";
import { AppRoutingModule } from "../app-routing.module";
import { LogInService } from "./logred.servise";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule ,FormsModule} from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import {CookieService} from "ngx-cookie-service"
import { LogEffects } from "./store/log.effects";
import { EffectsModule } from "@ngrx/effects";
import { logReducer } from "./store/log.reducer";
import { StoreModule } from "@ngrx/store";



@NgModule({
    declarations: [
      LoginComponent,
      RegisterComponent,
    ],
    imports: [
      BrowserModule,
      AppRoutingModule,
      CommonModule,
      ReactiveFormsModule,
      FormsModule,
      HttpClientModule,
      StoreModule.forFeature("logs", logReducer),
      EffectsModule.forFeature([LogEffects]),
    ],
    providers: [LogInService,CookieService],
    bootstrap: [LoginComponent,RegisterComponent],
    exports:[LoginComponent,RegisterComponent]
  })
  export class LogModule { }