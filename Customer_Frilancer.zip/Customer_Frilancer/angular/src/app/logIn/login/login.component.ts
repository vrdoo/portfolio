import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms"
import { UserService } from 'src/app/user/user.service';
import { LogInService } from '../logred.servise';
import { CookieService } from "ngx-cookie-service"
import { Router } from '@angular/router';
import { App } from 'src/app/app.type';
import { Store } from '@ngrx/store';
import * as LogAction from "../store/log.action"
import { getError, getTooken } from '../store/log.select';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  logInForm!: FormGroup
  errorMesage!: string
  tooken!: string
  logInerror!:string

  constructor(private service: LogInService, private cookis: CookieService, private router: Router, private store: Store<App>) {
    this.store.select(getTooken).subscribe((data) => {
      this.tooken = data
    })
    this.store.select(getError).subscribe((data) => {
      this.logInerror = data
    })
  }


  ngOnInit(): void {
    this.logInForm = new FormGroup({
      username: new FormControl(null, [
        Validators.required]),
      password: new FormControl(null, [
        Validators.required,
      ])
    })
    const token = this.cookis.get("token")
    if (token) {
      this.router.navigate(["profile"])
    }
  }

  logIn() {
    if (this.logInForm.valid) {
      this.store.dispatch(LogAction.getLogInStart({ obj: this.logInForm.value }))
    }    
    if (this.tooken) {
      this.cookis.set("token", this.tooken)
      this.router.navigate(["profile"])
    }
  }
}
