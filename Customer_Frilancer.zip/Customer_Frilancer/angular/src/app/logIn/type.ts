export interface UserLogIn{
    username:string,
    password:string
}

export interface UserAdd{
    name:string
    surname:string
    username:string
    role:string
    password:string
    salary:number
    profesion:string
}