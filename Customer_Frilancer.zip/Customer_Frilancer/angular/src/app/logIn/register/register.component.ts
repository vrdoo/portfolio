import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms"
import { LogInService } from '../logred.servise';
import { Router } from '@angular/router';
import { CookieService } from "ngx-cookie-service"
import { HttpClient } from '@angular/common/http';
import { mergeMap, map, of, catchError, Observable, EMPTY, exhaustMap } from "rxjs"
import { Store } from '@ngrx/store';
import { App } from 'src/app/app.type';
import { registerStart } from '../store/log.action';
import { getError } from '../store/log.select';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  registerForm!: FormGroup
  errorMessage!: string

  constructor(private service: LogInService, private router: Router, private cookis: CookieService, private http: HttpClient, private store: Store<App>) {
    store.select(getError).subscribe((err: any) => {
      console.log(err);
      this.errorMessage = err
    })
  }

  ngOnInit(): void {
    this.registerForm = new FormGroup({
      username: new FormControl(null, [
        Validators.required]),
      password: new FormControl(null, [
        Validators.required,
      ]),
      name: new FormControl(null, [
        Validators.required,
      ]),
      surname: new FormControl(null, [
        Validators.required,
      ]),
      profesion: new FormControl(null, [
      ]),
      salary: new FormControl(null, [
        Validators.required,
      ]),
      role: new FormControl(null, [
        Validators.required,
      ]),
    })

    const token = this.cookis.get("token")
    if (token) {
      this.router.navigate(["profile"])
    }
  }
  
  create() {
    if (this.registerForm.valid) {
      this.store.dispatch(registerStart({ user: this.registerForm.value }))
    }
  }

}
