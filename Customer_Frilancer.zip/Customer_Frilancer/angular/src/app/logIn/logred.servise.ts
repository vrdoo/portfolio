import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, delay, of } from "rxjs";
import {  UserAdd, UserLogIn } from "./type";


@Injectable()
export class LogInService{
    constructor(private http:HttpClient){}

    logIn(user:UserLogIn){
        return this.http.post("http://localhost:8080/auth/login",user)
    }

    register(user:UserAdd){
        return this.http.post("http://localhost:8080/user",user)
    }
}