import { Likecomment } from 'src/likecomment/entities/likecomment.entity';
import { Question } from 'src/question/entities/question.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Comment {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("text")
    text: string

    @Column()
    email: string

    @Column("int")
    questionId:number


    @ManyToOne(type => Question, ques => ques.comment, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    question: Question //question Id

    @OneToMany(type=>Likecomment,like=>like.comment)
    likecomment:Likecomment[]
}