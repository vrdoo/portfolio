import { Category } from 'src/category/entities/category.entity';
import { Comment } from 'src/comment/entities/comment.entity';
import { Likequestion } from 'src/likequestion/entities/likequestion.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Question {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    question: string;

    @Column("int")
    categoryId:number


    @ManyToOne(type => Category, cateory => cateory.question, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    category: Category


    @OneToMany(type => Comment, comm => comm.question)
    comment: Comment[]

    @OneToMany(type => Likequestion, like => like.question)
    likeques: Likequestion[]
}
