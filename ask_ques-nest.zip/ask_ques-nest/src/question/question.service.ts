import { Injectable } from '@nestjs/common';
import { CreateQuestionDto } from './dto/create-question.dto';
import { UpdateQuestionDto } from './dto/update-question.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Question } from './entities/question.entity';
import { Like, Repository } from 'typeorm';

@Injectable()
export class QuestionService {
  constructor(
    @InjectRepository(Question) private questionRepository: Repository<Question>,
  ) { }

  async create(createQuestionDto: CreateQuestionDto) {
    return await this.questionRepository.save(createQuestionDto);
  }

  async findAll() {
    return await this.questionRepository.find({
      relations: [
        "comment", "likeques", "category",
      ]
    });
  }

  async searchQuestion(updateQuestionDto: UpdateQuestionDto) {
    console.log(updateQuestionDto);
    return await this.questionRepository.find({
      where: {
        question: Like(`%${updateQuestionDto.text}%`)
      },
      relations: [
        "comment", "likeques", "category",
      ]
    })
  }

  findOne(id: number) {
    return this.questionRepository.findOne({
      where: {
        id: id
      },
      relations: [
        "comment", "likeques", "category", "comment.likecomment"
      ]
    });
  }

  update(id: number, updateQuestionDto: UpdateQuestionDto) {
    return `This action updates a #${id} question`;
  }

  remove(id: number) {
    return `This action removes a #${id} question`;
  }
}
