export class CreateQuestionDto {
}
