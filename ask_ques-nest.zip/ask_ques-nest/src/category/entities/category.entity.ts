import { Question } from 'src/question/entities/question.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Category {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    name:string

    @OneToMany(type=>Question,quess=>quess.category)
    question:Question[]
}

