import { Category } from 'src/category/entities/category.entity';
import { Question } from 'src/question/entities/question.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Likequestion {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("int")
    num:number

    @Column("int")
    questionId:number

    @ManyToOne(type=>Question,quess=>quess.likeques, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    question:Question
}