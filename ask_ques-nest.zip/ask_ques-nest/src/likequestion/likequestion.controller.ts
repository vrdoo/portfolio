import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { LikequestionService } from './likequestion.service';
import { CreateLikequestionDto } from './dto/create-likequestion.dto';
import { UpdateLikequestionDto } from './dto/update-likequestion.dto';

@Controller('likequestion')
export class LikequestionController {
  constructor(private readonly likequestionService: LikequestionService) {}

  @Post()
  create(@Body() createLikequestionDto: CreateLikequestionDto) {
    return this.likequestionService.create(createLikequestionDto);
  }

  @Get()
  findAll() {
    return this.likequestionService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.likequestionService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateLikequestionDto: UpdateLikequestionDto) {
    return this.likequestionService.update(+id, updateLikequestionDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.likequestionService.remove(+id);
  }
}
