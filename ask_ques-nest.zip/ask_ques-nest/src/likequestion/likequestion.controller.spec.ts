import { Test, TestingModule } from '@nestjs/testing';
import { LikequestionController } from './likequestion.controller';
import { LikequestionService } from './likequestion.service';

describe('LikequestionController', () => {
  let controller: LikequestionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [LikequestionController],
      providers: [LikequestionService],
    }).compile();

    controller = module.get<LikequestionController>(LikequestionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
