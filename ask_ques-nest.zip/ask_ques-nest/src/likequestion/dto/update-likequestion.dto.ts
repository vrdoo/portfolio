import { PartialType } from '@nestjs/mapped-types';
import { CreateLikequestionDto } from './create-likequestion.dto';

export class UpdateLikequestionDto extends PartialType(CreateLikequestionDto) {}
