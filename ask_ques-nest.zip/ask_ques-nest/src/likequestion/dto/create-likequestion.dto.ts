export class CreateLikequestionDto {}
