import { Injectable } from '@nestjs/common';
import { CreateLikequestionDto } from './dto/create-likequestion.dto';
import { UpdateLikequestionDto } from './dto/update-likequestion.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Likequestion } from './entities/likequestion.entity';
import { Repository } from 'typeorm';

@Injectable()
export class LikequestionService {
  constructor(
    @InjectRepository(Likequestion) private likeRepository: Repository<Likequestion>,
  ) { }

 async create(createLikequestionDto: CreateLikequestionDto) {
    return await this.likeRepository.save(createLikequestionDto);
  }

  findAll() {
    return `This action returns all likequestion`;
  }

  findOne(id: number) {
    return `This action returns a #${id} likequestion`;
  }

  update(id: number, updateLikequestionDto: UpdateLikequestionDto) {
    return `This action updates a #${id} likequestion`;
  }

  remove(id: number) {
    return `This action removes a #${id} likequestion`;
  }
}
