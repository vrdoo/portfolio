import { Test, TestingModule } from '@nestjs/testing';
import { LikequestionService } from './likequestion.service';

describe('LikequestionService', () => {
  let service: LikequestionService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [LikequestionService],
    }).compile();

    service = module.get<LikequestionService>(LikequestionService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
