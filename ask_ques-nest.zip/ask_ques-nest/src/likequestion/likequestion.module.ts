import { Module } from '@nestjs/common';
import { LikequestionService } from './likequestion.service';
import { LikequestionController } from './likequestion.controller';
import { Likequestion } from './entities/likequestion.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Likequestion])],
  controllers: [LikequestionController],
  providers: [LikequestionService]
})
export class LikequestionModule {}
