import { Category } from 'src/category/entities/category.entity';
import { Comment } from 'src/comment/entities/comment.entity';
import { Entity, Column, PrimaryGeneratedColumn, ManyToOne, OneToMany } from 'typeorm';



@Entity()
export class Likecomment {
    @PrimaryGeneratedColumn()
    id: number;

    @Column("int")
    num: number;

    @Column("int")
    commentId:number


    @ManyToOne(type => Comment, comm => comm.likecomment, {
        onUpdate: "CASCADE",
        onDelete: "CASCADE"
    })
    comment: Comment
}