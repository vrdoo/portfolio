import { Injectable } from '@nestjs/common';
import { CreateLikecommentDto } from './dto/create-likecomment.dto';
import { UpdateLikecommentDto } from './dto/update-likecomment.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Likecomment } from './entities/likecomment.entity';
import { Repository } from 'typeorm';

@Injectable()
export class LikecommentService {

  constructor(
    @InjectRepository(Likecomment) private likeRepository: Repository<Likecomment>,
  ) { }

  create(createLikecommentDto: CreateLikecommentDto) {
    return this.likeRepository.save(createLikecommentDto);
  }

  findAll() {
    return `This action returns all likecomment`;
  }

  findOne(id: number) {
    return `This action returns a #${id} likecomment`;
  }

  update(id: number, updateLikecommentDto: UpdateLikecommentDto) {
    return `This action updates a #${id} likecomment`;
  }

  remove(id: number) {
    return `This action removes a #${id} likecomment`;
  }
}
