import { Module } from '@nestjs/common';
import { LikecommentService } from './likecomment.service';
import { LikecommentController } from './likecomment.controller';
import { Likecomment } from './entities/likecomment.entity';
import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [TypeOrmModule.forFeature([Likecomment])],
  controllers: [LikecommentController],
  providers: [LikecommentService]
})
export class LikecommentModule {}
