export class CreateLikecommentDto {}
